// sukitickets/deploy-commands.js

/* ===================================================
   Enregistre les commandes slash auprès de Discord.
   À lancer une fois au début, puis à chaque fois
   qu'une commande est ajoutée ou modifiée :
       npm run deploy
   =================================================== */

require("dotenv").config();

const { REST, Routes } = require("discord.js");
const { listerFichiersCommandes } = require("./src/handlers/commandHandler");
const { t } = require("./src/utils/langue");

const { TOKEN, CLIENT_ID, GUILD_ID } = process.env;

if (!TOKEN || !CLIENT_ID) {
    console.error(t("deploy.manque"));
    process.exit(1);
}

// On récupère la description de chaque commande
const commandes = listerFichiersCommandes()
    .map((fichier) => require(fichier))
    .filter((commande) => commande.data)
    .map((commande) => commande.data.toJSON());

const rest = new REST().setToken(TOKEN);

(async () => {
    try {
        console.log(t("deploy.envoi", { nombre: commandes.length }));

        if (GUILD_ID) {
            // Sur un seul serveur : les commandes apparaissent tout de suite
            await rest.put(Routes.applicationGuildCommands(CLIENT_ID, GUILD_ID), { body: commandes });
            console.log(t("deploy.okServeur"));
        } else {
            // Sur tous les serveurs : peut prendre jusqu'à une heure
            await rest.put(Routes.applicationCommands(CLIENT_ID), { body: commandes });
            console.log(t("deploy.okGlobal"));
        }
    } catch (erreur) {
        console.error(t("deploy.erreur"), erreur);
    }
})();