// sukitickets/src/events/channelDelete.js

/* ===================================================
   Salon supprimé
   Si quelqu'un supprime un salon de ticket à la main
   (sans utiliser le bouton Fermer), on oublie ce
   ticket : le membre pourra en ouvrir un nouveau.
   =================================================== */

const { Events } = require("discord.js");
const { lireTickets, ecrireTickets } = require("../utils/donnees");

module.exports = {
    name: Events.ChannelDelete,

    execute(salon) {
        if (!salon.guild) return;

        const tickets = lireTickets(salon.guild.id);
        if (!tickets.ouverts[salon.id]) return;

        delete tickets.ouverts[salon.id];
        ecrireTickets(salon.guild.id, tickets);
    },
};