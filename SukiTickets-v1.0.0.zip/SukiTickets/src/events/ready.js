// sukitickets/src/events/ready.js

/* ===================================================
   Bot connecté
   Affiche un message dans la console
   et met à jour le statut du bot.
   =================================================== */

const { Events, ActivityType } = require("discord.js");
const { t } = require("../utils/langue");

module.exports = {
    name: Events.ClientReady,
    once: true,

    execute(client) {
        const version = client.estPremium ? t("general.versionPremium") : t("general.versionStandard");

        console.log("─────────────────────────────────────");
        console.log(t("console.enLigne", { tag: client.user.tag }));
        console.log(t("console.version", { version }));
        console.log(t("console.serveurs", { nombre: client.guilds.cache.size }));
        console.log(t("console.astuceSetup"));
        console.log("─────────────────────────────────────");

        // Statut affiché sous le nom du bot (réglable dans config.json)
        const { type, texte } = client.config.statut;

        client.user.setActivity(texte, {
            type: ActivityType[type] ?? ActivityType.Watching,
        });
    },
};