// sukitickets/src/events/interactionCreate.js

/* ===================================================
   Réception des interactions
   - Commandes slash   → src/commands
   - Autocomplétion    → fonction autocomplete() de la commande
   - Boutons, menus et fenêtres → src/composants
     (choisi grâce au début de l'identifiant,
      par exemple "setup:roles" → composants/setup.js)
   =================================================== */

const { Events, MessageFlags } = require("discord.js");
const { t } = require("../utils/langue");
const { lireServeur } = require("../utils/donnees");

/** Répond "une erreur est survenue" sans faire planter le bot */
async function repondreErreur(interaction, texte) {
    const message = { content: texte, flags: MessageFlags.Ephemeral };

    if (interaction.replied || interaction.deferred) {
        await interaction.followUp(message).catch(() => {});
    } else {
        await interaction.reply(message).catch(() => {});
    }
}

module.exports = {
    name: Events.InteractionCreate,

    async execute(interaction, client) {
        // Langue du serveur (choisie avec /setup)
        const langue = interaction.guildId ? lireServeur(interaction.guildId).langue : client.config.langue;

        /* ---------- Autocomplétion (suggestions pendant la saisie d'une option) ---------- */

        if (interaction.isAutocomplete()) {
            const commande = client.commands.get(interaction.commandName);
            if (commande?.autocomplete) await commande.autocomplete(interaction, client).catch(() => {});
            return;
        }

        /* ---------- Commandes slash ---------- */

        if (interaction.isChatInputCommand()) {
            const commande = client.commands.get(interaction.commandName);

            if (!commande) {
                console.warn(t("console.commandeInconnue", { commande: interaction.commandName }));
                return;
            }

            try {
                await commande.execute(interaction, client);
            } catch (erreur) {
                console.error(t("console.erreurCommande", { commande: interaction.commandName }), erreur);
                await repondreErreur(interaction, t("erreurs.commande", {}, langue));
            }
            return;
        }

        /* ---------- Boutons, menus et fenêtres ---------- */

        if (interaction.isMessageComponent() || interaction.isModalSubmit()) {
            const prefixe = interaction.customId.split(":")[0];
            const composant = client.composants.get(prefixe);

            if (!composant) return;

            try {
                await composant.execute(interaction, client);
            } catch (erreur) {
                console.error(t("console.erreurComposant", { id: interaction.customId }), erreur);
                await repondreErreur(interaction, t("erreurs.composant", {}, langue));
            }
        }
    },
};