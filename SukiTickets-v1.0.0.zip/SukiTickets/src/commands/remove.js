// sukitickets/src/commands/remove.js

/* ===================================================
   /remove membre — retire un membre du ticket
   (réservé au staff, dans un salon de ticket)
   En français, la commande s'affiche « /retirer ».
   On ne peut retirer ni l'auteur du ticket, ni un
   membre du staff (son rôle lui donne accès).
   =================================================== */

const { SlashCommandBuilder, InteractionContextType, MessageFlags, EmbedBuilder } = require("discord.js");

const { t, localisations } = require("../utils/langue");
const { verifierCommandeTicket, estStaff } = require("../utils/staff");
const { envoyerLog } = require("../tickets/logs");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("remove")
        .setNameLocalizations({ fr: "retirer" })
        .setDescription(t("commandes.remove.description", {}, "en"))
        .setDescriptionLocalizations(localisations("commandes.remove.description"))
        .setContexts(InteractionContextType.Guild)
        .addUserOption((option) => option
            .setName("member")
            .setNameLocalizations({ fr: "membre" })
            .setDescription(t("commandes.remove.optionMembre", {}, "en"))
            .setDescriptionLocalizations(localisations("commandes.remove.optionMembre"))
            .setRequired(true)),

    async execute(interaction, client) {
        const contexte = await verifierCommandeTicket(interaction);
        if (!contexte) return;
        const { ticket, reglages, L } = contexte;
        const prive = (content) => ({ content, flags: MessageFlags.Ephemeral });

        const cible = interaction.options.getMember("member");
        if (!cible) return interaction.reply(prive(t("gestion.membreIntrouvable", {}, L)));

        if (cible.id === ticket.auteur) return interaction.reply(prive(t("gestion.auteurNonRetirable", {}, L)));
        if (estStaff(cible, reglages)) {
            return interaction.reply(prive(t("gestion.staffNonRetirable", { membre: `<@${cible.id}>` }, L)));
        }

        try {
            await interaction.channel.permissionOverwrites.delete(cible.id);
        } catch (erreur) {
            console.error(erreur);
            return interaction.reply(prive(t("gestion.erreurPermissions", {}, L)));
        }

        await interaction.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor(client.config.couleurs.erreur)
                    .setDescription(t("gestion.membreRetire", { membre: `<@${cible.id}>`, staff: `<@${interaction.user.id}>` }, L)),
            ],
            allowedMentions: { parse: [] },
        });

        await envoyerLog(interaction.guild, client, {
            titre: t("logs.titreRetrait", {}, L),
            couleur: client.config.couleurs.info,
            champs: [
                { name: t("logs.champTicket", {}, L), value: `#${String(ticket.numero).padStart(4, "0")} · <#${interaction.channelId}>` },
                { name: t("logs.champMembre", {}, L), value: `<@${cible.id}>` },
                { name: t("logs.champPar", {}, L), value: `<@${interaction.user.id}>` },
            ],
        });
    },
};