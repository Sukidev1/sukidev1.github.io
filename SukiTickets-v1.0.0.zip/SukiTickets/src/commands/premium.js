// sukitickets/src/commands/premium.js

/* ===================================================
   /premium — présente SukiTickets Premium
   - Version gratuite : les avantages, le prix et un
     bouton « Acheter » vers la page du produit.
   - Version premium : un message de remerciement
     avec la liste des fonctions actives.
   =================================================== */

const {
    SlashCommandBuilder,
    EmbedBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    MessageFlags,
} = require("discord.js");

const { t, localisations } = require("../utils/langue");
const { lireServeur } = require("../utils/donnees");
const { PRIX_PREMIUM, LIEN_PRODUIT, LIEN_SITE, piedDePage } = require("../utils/marque");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("premium")
        .setDescription(t("commandes.premium.description", {}, "en"))
        .setDescriptionLocalizations(localisations("commandes.premium.description")),

    async execute(interaction, client) {
        const L = interaction.guildId ? lireServeur(interaction.guildId).langue : client.config.langue;
        const { couleurs } = client.config;

        /* ---------- Déjà premium : merci ! ---------- */

        if (client.estPremium) {
            return interaction.reply({
                embeds: [
                    new EmbedBuilder()
                        .setColor(couleurs.succes)
                        .setTitle(t("offre.dejaPremiumTitre", {}, L))
                        .setDescription(t("offre.dejaPremium", {}, L))
                        .setFooter({ text: piedDePage(client, L) }),
                ],
                flags: MessageFlags.Ephemeral,
            });
        }

        /* ---------- Version gratuite : l'offre ---------- */

        const embed = new EmbedBuilder()
            .setColor(couleurs.principale)
            .setTitle(t("offre.titre", {}, L))
            .setDescription([
                t("offre.intro", {}, L),
                "",
                t("offre.formulaire", {}, L),
                t("offre.fermetureAuto", {}, L),
                t("offre.notes", {}, L),
                t("offre.stats", {}, L),
                t("offre.priorite", {}, L),
            ].join("\n\n"))
            .addFields(
                { name: t("offre.champPrix", {}, L), value: t("offre.prix", { prix: PRIX_PREMIUM }, L), inline: true },
                { name: t("offre.champInstallation", {}, L), value: t("offre.installation", {}, L), inline: true },
            )
            .setFooter({ text: piedDePage(client, L) });

        const boutons = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setLabel(t("offre.boutonAcheter", { prix: PRIX_PREMIUM }, L))
                .setEmoji("💳")
                .setStyle(ButtonStyle.Link)
                .setURL(LIEN_PRODUIT),
            new ButtonBuilder()
                .setLabel(t("offre.boutonSite", {}, L))
                .setEmoji("🌙")
                .setStyle(ButtonStyle.Link)
                .setURL(LIEN_SITE),
        );

        return interaction.reply({ embeds: [embed], components: [boutons], flags: MessageFlags.Ephemeral });
    },
};