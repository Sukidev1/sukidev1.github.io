// sukitickets/src/commands/rename.js

/* ===================================================
   /rename nom — renomme le salon du ticket
   (réservé au staff, dans un salon de ticket)
   En français, la commande s'affiche « /renommer ».

   Attention : Discord n'autorise que 2 renommages
   toutes les 10 minutes par salon. Si la limite est
   atteinte, le bot prévient que le nom changera dès
   que possible.
   =================================================== */

const { SlashCommandBuilder, InteractionContextType, MessageFlags, EmbedBuilder } = require("discord.js");

const { t, localisations } = require("../utils/langue");
const { verifierCommandeTicket } = require("../utils/staff");
const { envoyerLog } = require("../tickets/logs");

// Au-delà de ce délai, on considère que Discord fait attendre le renommage
const ATTENTE_MAX = 4000;

module.exports = {
    data: new SlashCommandBuilder()
        .setName("rename")
        .setNameLocalizations({ fr: "renommer" })
        .setDescription(t("commandes.rename.description", {}, "en"))
        .setDescriptionLocalizations(localisations("commandes.rename.description"))
        .setContexts(InteractionContextType.Guild)
        .addStringOption((option) => option
            .setName("name")
            .setNameLocalizations({ fr: "nom" })
            .setDescription(t("commandes.rename.optionNom", {}, "en"))
            .setDescriptionLocalizations(localisations("commandes.rename.optionNom"))
            .setMaxLength(90)
            .setRequired(true)),

    async execute(interaction, client) {
        const contexte = await verifierCommandeTicket(interaction);
        if (!contexte) return;
        const { ticket, L } = contexte;

        const nom = interaction.options.getString("name");
        const salon = interaction.channel;

        // Le renommage peut être mis en attente par Discord : on répond tout de suite en privé
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });

        const renommage = salon.setName(nom);
        const resultat = await Promise.race([
            renommage.then(() => "fait").catch(() => "erreur"),
            new Promise((resoudre) => setTimeout(() => resoudre("lent"), ATTENTE_MAX)),
        ]);

        if (resultat === "erreur") return interaction.editReply(t("gestion.erreurPermissions", {}, L));

        if (resultat === "lent") {
            await interaction.editReply(t("gestion.renommageLent", {}, L));
            await renommage.catch(() => null);   // on attend la fin du renommage avant d'annoncer
        } else {
            await interaction.editReply(t("gestion.fait", {}, L));
        }

        // Annonce dans le ticket (avec le nom final, Discord peut l'avoir modifié : minuscules, tirets…)
        await salon.send({
            embeds: [
                new EmbedBuilder()
                    .setColor(client.config.couleurs.info)
                    .setDescription(t("gestion.renomme", { nom: salon.name, staff: `<@${interaction.user.id}>` }, L)),
            ],
            allowedMentions: { parse: [] },
        }).catch(() => {});

        await envoyerLog(interaction.guild, client, {
            titre: t("logs.titreRenommage", {}, L),
            couleur: client.config.couleurs.info,
            champs: [
                { name: t("logs.champTicket", {}, L), value: `#${String(ticket.numero).padStart(4, "0")} · <#${salon.id}>` },
                { name: t("logs.champNouveauNom", {}, L), value: `\`${salon.name}\`` },
                { name: t("logs.champPar", {}, L), value: `<@${interaction.user.id}>` },
            ],
        });
    },
};