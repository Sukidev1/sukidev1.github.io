// sukitickets/src/commands/panel.js

/* ===================================================
   /panel — envoie le menu des tickets dans un salon
   Réservé aux administrateurs. Options :
     salon        → où l'envoyer (par défaut : ici)
     titre        → titre personnalisé
     description  → texte personnalisé
   =================================================== */

const {
    SlashCommandBuilder,
    PermissionFlagsBits,
    InteractionContextType,
    ChannelType,
    MessageFlags,
} = require("discord.js");

const { t, localisations } = require("../utils/langue");
const { lireServeur, modifierServeur } = require("../utils/donnees");
const { etatServeur } = require("../utils/verifierConfig");
const { construireMenuTickets } = require("../tickets/panneauTickets");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("panel")
        .setDescription(t("commandes.panel.description", {}, "en"))
        .setDescriptionLocalizations(localisations("commandes.panel.description"))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
        .setContexts(InteractionContextType.Guild)
        .addChannelOption((option) => option
            .setName("salon")
            .setNameLocalizations({ "en-US": "channel", "en-GB": "channel" })
            .setDescription(t("commandes.panel.optionSalon", {}, "en"))
            .setDescriptionLocalizations(localisations("commandes.panel.optionSalon"))
            .addChannelTypes(ChannelType.GuildText)
            .setRequired(false))
        .addStringOption((option) => option
            .setName("titre")
            .setNameLocalizations({ "en-US": "title", "en-GB": "title" })
            .setDescription(t("commandes.panel.optionTitre", {}, "en"))
            .setDescriptionLocalizations(localisations("commandes.panel.optionTitre"))
            .setMaxLength(256)
            .setRequired(false))
        .addStringOption((option) => option
            .setName("description")
            .setDescription(t("commandes.panel.optionDescription", {}, "en"))
            .setDescriptionLocalizations(localisations("commandes.panel.optionDescription"))
            .setMaxLength(1000)
            .setRequired(false)),

    async execute(interaction, client) {
        const serveur = interaction.guild;
        const reglages = lireServeur(serveur.id);
        const L = reglages.langue;
        const prive = (content) => ({ content, flags: MessageFlags.Ephemeral });

        // 1) La configuration doit être terminée
        if (!etatServeur(serveur, reglages).pret) {
            return interaction.reply(prive(t("panel.pasPret", {}, L)));
        }

        // 2) Le bot doit pouvoir écrire dans le salon choisi
        const salon = interaction.options.getChannel("salon") ?? interaction.channel;
        const droits = salon.permissionsFor(serveur.members.me);
        const peutEcrire = droits?.has([
            PermissionFlagsBits.ViewChannel,
            PermissionFlagsBits.SendMessages,
            PermissionFlagsBits.EmbedLinks,
        ]);

        if (!peutEcrire) {
            return interaction.reply(prive(t("panel.permissionsSalon", { salon: `<#${salon.id}>` }, L)));
        }

        // 3) Envoi du menu
        // Les "\n" tapés dans l'option description deviennent de vrais retours à la ligne
        const titre = interaction.options.getString("titre");
        const description = interaction.options.getString("description")?.replace(/\\n/g, "\n") ?? null;

        const message = await salon.send(construireMenuTickets(reglages, client, { titre, description }));

        // 4) On s'en souvient pour pouvoir le mettre à jour plus tard
        modifierServeur(serveur.id, {
            panneaux: [...reglages.panneaux, { salon: salon.id, message: message.id, titre, description }],
        });

        return interaction.reply(prive(t("panel.envoye", { salon: `<#${salon.id}>` }, L)));
    },
};