// sukitickets/src/commands/setup.js

/* ===================================================
   /setup — panneau de configuration du bot
   Réservé aux administrateurs. Le panneau n'est
   visible que par la personne qui tape la commande.
   =================================================== */

const { SlashCommandBuilder, PermissionFlagsBits, InteractionContextType, MessageFlags } = require("discord.js");
const { t, localisations } = require("../utils/langue");
const { construirePanneau } = require("../setup/panneau");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("setup")
        .setDescription(t("commandes.setup.description", {}, "en"))
        .setDescriptionLocalizations(localisations("commandes.setup.description"))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator) // visible seulement par les admins
        .setContexts(InteractionContextType.Guild),                    // seulement sur un serveur, pas en MP

    async execute(interaction, client) {
        await interaction.reply({
            ...construirePanneau(interaction.guild, client),
            flags: MessageFlags.Ephemeral,
        });
    },
};