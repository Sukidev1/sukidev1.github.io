// sukitickets/src/commands/add.js

/* ===================================================
   /add membre — ajoute un membre au ticket
   (réservé au staff, dans un salon de ticket)
   En français, la commande s'affiche « /ajouter ».
   =================================================== */

const { SlashCommandBuilder, InteractionContextType, MessageFlags, EmbedBuilder } = require("discord.js");

const { t, localisations } = require("../utils/langue");
const { verifierCommandeTicket } = require("../utils/staff");
const { envoyerLog } = require("../tickets/logs");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("add")
        .setNameLocalizations({ fr: "ajouter" })
        .setDescription(t("commandes.add.description", {}, "en"))
        .setDescriptionLocalizations(localisations("commandes.add.description"))
        .setContexts(InteractionContextType.Guild)
        .addUserOption((option) => option
            .setName("member")
            .setNameLocalizations({ fr: "membre" })
            .setDescription(t("commandes.add.optionMembre", {}, "en"))
            .setDescriptionLocalizations(localisations("commandes.add.optionMembre"))
            .setRequired(true)),

    async execute(interaction, client) {
        const contexte = await verifierCommandeTicket(interaction);
        if (!contexte) return;
        const { ticket, L } = contexte;

        const cible = interaction.options.getMember("member");
        if (!cible) {
            return interaction.reply({ content: t("gestion.membreIntrouvable", {}, L), flags: MessageFlags.Ephemeral });
        }

        try {
            await interaction.channel.permissionOverwrites.edit(cible.id, {
                ViewChannel: true,
                SendMessages: true,
                ReadMessageHistory: true,
                AttachFiles: true,
                EmbedLinks: true,
            });
        } catch (erreur) {
            console.error(erreur);
            return interaction.reply({ content: t("gestion.erreurPermissions", {}, L), flags: MessageFlags.Ephemeral });
        }

        // Annonce dans le ticket (le membre ajouté est mentionné pour qu'il le voie)
        await interaction.reply({
            embeds: [
                new EmbedBuilder()
                    .setColor(client.config.couleurs.succes)
                    .setDescription(t("gestion.membreAjoute", { membre: `<@${cible.id}>`, staff: `<@${interaction.user.id}>` }, L)),
            ],
            content: `<@${cible.id}>`,
            allowedMentions: { users: [cible.id] },
        });

        await envoyerLog(interaction.guild, client, {
            titre: t("logs.titreAjout", {}, L),
            couleur: client.config.couleurs.info,
            champs: [
                { name: t("logs.champTicket", {}, L), value: `#${String(ticket.numero).padStart(4, "0")} · <#${interaction.channelId}>` },
                { name: t("logs.champMembre", {}, L), value: `<@${cible.id}>` },
                { name: t("logs.champPar", {}, L), value: `<@${interaction.user.id}>` },
            ],
        });
    },
};