// sukitickets/src/tickets/panneauTickets.js

/* ===================================================
   Menu des tickets (le message envoyé par /panel)
   - construireMenuTickets : fabrique le message avec
     le menu déroulant des catégories
   - rafraichirPanneaux : met à jour tous les menus
     déjà envoyés sur un serveur (quand une catégorie
     ou la langue change, par exemple)
   =================================================== */

const { EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder } = require("discord.js");

const { t } = require("../utils/langue");
const { lireServeur, modifierServeur } = require("../utils/donnees");
const { emojiComposant } = require("../utils/emoji");
const { piedDePage } = require("../utils/marque");

/**
 * Renvoie { embeds, components } du menu des tickets.
 * "titre" et "description" sont ceux choisis avec /panel (ou null pour les textes par défaut).
 */
function construireMenuTickets(reglages, client, { titre = null, description = null } = {}) {
    const L = reglages.langue;

    const embed = new EmbedBuilder()
        .setColor(client.config.couleurs.principale)
        .setTitle(titre || t("panel.titreDefaut", {}, L))
        .setDescription(description || t("panel.descriptionDefaut", {}, L))
        .setFooter({ text: piedDePage(client, L) });

    const options = reglages.categories.map((categorie) => {
        const option = new StringSelectMenuOptionBuilder()
            .setLabel(categorie.nom)
            .setValue(categorie.id);
        if (categorie.description) option.setDescription(categorie.description);
        if (categorie.emoji) option.setEmoji(emojiComposant(categorie.emoji));
        return option;
    });

    const menu = new StringSelectMenuBuilder()
        .setCustomId("ticket:ouvrir")
        .setPlaceholder(t("panel.menu", {}, L))
        .addOptions(options);

    return { embeds: [embed], components: [new ActionRowBuilder().addComponents(menu)] };
}

/**
 * Met à jour tous les menus de tickets déjà envoyés sur ce serveur.
 * Les menus supprimés entre-temps sont oubliés.
 * Renvoie le nombre de menus mis à jour.
 */
async function rafraichirPanneaux(serveur, client) {
    const reglages = lireServeur(serveur.id);
    const encorePresents = [];

    for (const panneau of reglages.panneaux) {
        const salon = serveur.channels.cache.get(panneau.salon);
        const message = salon ? await salon.messages.fetch(panneau.message).catch(() => null) : null;

        if (!message) continue;

        await message.edit(construireMenuTickets(reglages, client, panneau)).catch(() => {});
        encorePresents.push(panneau);
    }

    if (encorePresents.length !== reglages.panneaux.length) {
        modifierServeur(serveur.id, { panneaux: encorePresents });
    }

    return encorePresents.length;
}

module.exports = { construireMenuTickets, rafraichirPanneaux };