// sukitickets/src/tickets/creation.js

/* ===================================================
   Création d'un ticket
   - ticketsOuvertsDe : les tickets encore ouverts
     d'un membre (pour la limite par membre)
   - creerTicket : crée le salon privé, envoie le
     message d'accueil et enregistre le ticket
   - construireAccueil : le message d'accueil avec
     ses boutons (réutilisé quand le ticket est
     pris en charge, à l'étape suivante)
   =================================================== */

const {
    ChannelType,
    PermissionFlagsBits,
    EmbedBuilder,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    MessageFlags,
} = require("discord.js");

const { t } = require("../utils/langue");
const { lireServeur, lireTickets, ecrireTickets } = require("../utils/donnees");
const { declencher } = require("./hooks");
const { envoyerLog } = require("./logs");
const { piedDePage } = require("../utils/marque");

const prive = (content) => ({ content, flags: MessageFlags.Ephemeral });

/** "Aide boutique" → "aide-boutique" (pour le nom du salon) */
function enSlug(texte) {
    return texte
        .normalize("NFD").replace(/[̀-ͯ]/g, "")
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/^-|-$/g, "")
        .slice(0, 80) || "ticket";
}

/**
 * Liste les salons des tickets encore ouverts par ce membre.
 * Au passage, oublie les tickets dont le salon a disparu.
 */
function ticketsOuvertsDe(serveur, idMembre) {
    const tickets = lireTickets(serveur.id);
    let nettoyage = false;

    for (const idSalon of Object.keys(tickets.ouverts)) {
        if (!serveur.channels.cache.has(idSalon)) {
            delete tickets.ouverts[idSalon];
            nettoyage = true;
        }
    }

    if (nettoyage) ecrireTickets(serveur.id, tickets);

    return Object.entries(tickets.ouverts)
        .filter(([, ticket]) => ticket.auteur === idMembre)
        .map(([idSalon]) => idSalon);
}

/**
 * Message d'accueil du ticket (embed + boutons).
 */
function construireAccueil(ticket, categorie, reglages, client) {
    const L = reglages.langue;
    const numero = String(ticket.numero).padStart(4, "0");
    const nomCategorie = `${categorie?.emoji ?? "🎫"} ${categorie?.nom ?? ticket.categorie}`;

    const embed = new EmbedBuilder()
        .setColor(client.config.couleurs.principale)
        .setTitle(t("tickets.titreAccueil", { numero, categorie: nomCategorie }, L))
        .setDescription(t("tickets.messageAccueil", { membre: `<@${ticket.auteur}>` }, L))
        .addFields(
            { name: t("tickets.champCategorie", {}, L), value: nomCategorie, inline: true },
            { name: t("tickets.champAuteur", {}, L), value: `<@${ticket.auteur}>`, inline: true },
            {
                name: t("tickets.champPrisEnCharge", {}, L),
                value: ticket.prisEnCharge ? `<@${ticket.prisEnCharge}>` : t("tickets.personne", {}, L),
                inline: true,
            },
        )
        .setFooter({ text: piedDePage(client, L) })
        .setTimestamp(ticket.ouvertLe);

    const boutons = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId("ticket:prendre")
            .setLabel(t("tickets.boutonPrendre", {}, L))
            .setEmoji("🙋")
            .setStyle(ButtonStyle.Success)
            .setDisabled(Boolean(ticket.prisEnCharge)),
        new ButtonBuilder()
            .setCustomId("ticket:fermer")
            .setLabel(t("tickets.boutonFermer", {}, L))
            .setEmoji("🔒")
            .setStyle(ButtonStyle.Danger),
    );

    const embeds = [embed];

    // Réponses au formulaire (version premium)
    if (ticket.reponses?.length) {
        embeds.push(new EmbedBuilder()
            .setColor(client.config.couleurs.info)
            .setTitle(t("tickets.titreReponses", {}, L))
            .addFields(ticket.reponses.map(({ question, reponse }) => ({ name: question, value: reponse || "—" }))));
    }

    return { embeds, components: [boutons] };
}

/**
 * Crée le ticket. L'interaction doit déjà avoir reçu une réponse
 * (update ou defer) : on répond au membre avec followUp.
 * "reponses" : réponses à un formulaire (version premium), sinon null.
 */
async function creerTicket(interaction, client, categorie, reponses = null) {
    const serveur = interaction.guild;
    const membre = interaction.user;
    const reglages = lireServeur(serveur.id);
    const L = reglages.langue;

    // Nouveau numéro de ticket (enregistré tout de suite pour ne jamais le réutiliser)
    const tickets = lireTickets(serveur.id);
    tickets.compteur += 1;
    const numero = tickets.compteur;
    ecrireTickets(serveur.id, tickets);

    const numeroTexte = String(numero).padStart(4, "0");

    // Permissions du salon : le membre, le staff et le bot uniquement
    const droitsDiscussion = [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.ReadMessageHistory,
        PermissionFlagsBits.AttachFiles,
        PermissionFlagsBits.EmbedLinks,
    ];

    const permissions = [
        { id: serveur.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
        { id: membre.id, allow: droitsDiscussion },
        ...reglages.rolesStaff.map((id) => ({ id, allow: [...droitsDiscussion, PermissionFlagsBits.ManageMessages] })),
        { id: client.user.id, allow: [...droitsDiscussion, PermissionFlagsBits.ManageChannels] },
    ];

    let salon;
    try {
        salon = await serveur.channels.create({
            name: `${enSlug(categorie.nom)}-${numeroTexte}`,
            type: ChannelType.GuildText,
            parent: reglages.categorieTickets,
            topic: t("tickets.sujet", { numero: numeroTexte, categorie: categorie.nom, membre: membre.username }, L),
            permissionOverwrites: permissions,
        });
    } catch (erreur) {
        console.error(erreur);

        // On rend le numéro si personne n'en a pris un autre entre-temps
        const annulation = lireTickets(serveur.id);
        if (annulation.compteur === numero) {
            annulation.compteur -= 1;
            ecrireTickets(serveur.id, annulation);
        }

        return interaction.followUp(prive(t("tickets.erreurCreation", {}, L)));
    }

    // Le ticket tel qu'il est enregistré
    const ticket = {
        numero,
        auteur: membre.id,
        categorie: categorie.id,
        ouvertLe: Date.now(),
        prisEnCharge: null,
        messageAccueil: null,
        reponses,
    };

    // Message d'accueil : mentionne le membre et le staff
    const mentions = [`<@${membre.id}>`, ...reglages.rolesStaff.map((id) => `<@&${id}>`)].join(" ");
    const accueil = await salon.send({
        content: mentions,
        ...construireAccueil(ticket, categorie, reglages, client),
        allowedMentions: { users: [membre.id], roles: reglages.rolesStaff },
    });

    ticket.messageAccueil = accueil.id;

    const aJour = lireTickets(serveur.id);
    aJour.ouverts[salon.id] = ticket;
    ecrireTickets(serveur.id, aJour);

    await interaction.followUp(prive(t("tickets.cree", { salon: `<#${salon.id}>` }, L)));

    // Résumé dans le salon de logs
    await envoyerLog(serveur, client, {
        titre: t("logs.titreOuverture", {}, L),
        couleur: client.config.couleurs.info,
        champs: [
            { name: t("logs.champTicket", {}, L), value: `#${numeroTexte}` },
            { name: t("logs.champCategorie", {}, L), value: `${categorie.emoji ?? "🎫"} ${categorie.nom}` },
            { name: t("logs.champAuteur", {}, L), value: `<@${membre.id}>` },
            { name: t("logs.champSalon", {}, L), value: `<#${salon.id}>` },
        ],
    });

    // Version premium : actions supplémentaires (priorité, etc.)
    await declencher("apresCreation", { interaction, client, salon, ticket, categorie, reglages });

    return salon;
}

module.exports = { creerTicket, ticketsOuvertsDe, construireAccueil };