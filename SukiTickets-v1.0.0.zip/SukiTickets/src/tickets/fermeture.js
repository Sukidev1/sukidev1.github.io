// sukitickets/src/tickets/fermeture.js

/* ===================================================
   Fermeture d'un ticket
   fermerTicket(salon, membre, client) :
     1) annonce la fermeture dans le salon
     2) retire le ticket des tickets ouverts et le
        garde dans l'historique (pour les stats)
     3) crée la transcription HTML, l'envoie dans le
        salon de logs avec un résumé, et en copie
        privée à l'auteur du ticket
     4) prévient la version premium
     5) affiche un compte à rebours puis supprime
        le salon

   Utilisée par le bouton « Fermer », et plus tard
   par la fermeture automatique (premium).
   "membre" vaut null quand la fermeture est automatique.
   =================================================== */

const { EmbedBuilder, AttachmentBuilder } = require("discord.js");

const { t } = require("../utils/langue");
const { lireServeur, lireTickets, ecrireTickets } = require("../utils/donnees");
const { formaterDuree } = require("../utils/duree");
const { declencher } = require("./hooks");
const { envoyerLog } = require("./logs");
const { creerTranscription } = require("./transcription");
const { piedDePage } = require("../utils/marque");

// On garde les 500 derniers tickets fermés par serveur
const TAILLE_HISTORIQUE = 500;

// Salons en train de se fermer (évite de fermer deux fois)
const fermeturesEnCours = new Set();

const attendre = (ms) => new Promise((resoudre) => setTimeout(resoudre, ms));

/** Ce salon est-il en train de se fermer ? */
function estEnFermeture(idSalon) {
    return fermeturesEnCours.has(idSalon);
}

/** Nom affichable d'un membre à partir de son id */
async function nomDe(client, id) {
    if (!id) return null;
    const utilisateur = await client.users.fetch(id).catch(() => null);
    return utilisateur ? (utilisateur.globalName ?? utilisateur.username) : id;
}

/* ---------- Transcription + logs + MP ---------- */

async function archiver(salon, ticket, membre, fermeLe, client, reglages) {
    const serveur = salon.guild;
    const L = reglages.langue;
    const numero = String(ticket.numero).padStart(4, "0");
    const categorie = reglages.categories.find((c) => c.id === ticket.categorie);
    const nomCategorie = categorie ? `${categorie.emoji ?? "🎫"} ${categorie.nom}` : ticket.categorie;

    // 1) Transcription HTML
    let transcription = null;
    try {
        transcription = await creerTranscription(salon, ticket, {
            serveur: serveur.name,
            categorie: nomCategorie,
            auteur: await nomDe(client, ticket.auteur),
            prisEnCharge: await nomDe(client, ticket.prisEnCharge),
            fermePar: membre ? (membre.globalName ?? membre.username) : t("logs.automatique", {}, L),
            ouvertLe: ticket.ouvertLe,
            fermeLe,
        }, L);
    } catch (erreur) {
        console.warn(t("console.erreurTranscription"), erreur.message);
    }

    const nomFichier = `transcript-${salon.name}.html`;
    const fichier = () => (transcription ? [new AttachmentBuilder(Buffer.from(transcription.html, "utf8"), { name: nomFichier })] : []);

    // 2) Résumé dans le salon de logs
    await envoyerLog(serveur, client, {
        titre: t("logs.titreFermeture", {}, L),
        couleur: client.config.couleurs.erreur,
        description: transcription ? t("logs.transcriptionJointe", {}, L) : t("logs.transcriptionEchec", {}, L),
        champs: [
            { name: t("logs.champTicket", {}, L), value: `#${numero} · \`${salon.name}\`` },
            { name: t("logs.champCategorie", {}, L), value: nomCategorie },
            { name: t("logs.champAuteur", {}, L), value: `<@${ticket.auteur}>` },
            { name: t("logs.champPrisEnCharge", {}, L), value: ticket.prisEnCharge ? `<@${ticket.prisEnCharge}>` : t("logs.personne", {}, L) },
            { name: t("logs.champFermePar", {}, L), value: membre ? `<@${membre.id}>` : t("logs.automatique", {}, L) },
            { name: t("logs.champDuree", {}, L), value: formaterDuree(fermeLe - ticket.ouvertLe, L) },
            ...(transcription ? [{ name: t("logs.champMessages", {}, L), value: String(transcription.nombreMessages) }] : []),
        ],
        fichiers: fichier(),
    });

    // 3) Copie privée pour l'auteur (s'il accepte les messages privés)
    const auteur = await client.users.fetch(ticket.auteur).catch(() => null);
    if (auteur) {
        await auteur.send({
            embeds: [
                new EmbedBuilder()
                    .setColor(client.config.couleurs.principale)
                    .setTitle(t("dm.titre", { numero }, L))
                    .setDescription(t("dm.description", { serveur: serveur.name }, L))
                    .setFooter({ text: piedDePage(client, L) }),
            ],
            files: fichier(),
        }).catch(() => {}); // MP fermés : pas grave
    }

    return transcription;
}

/* ---------- Fermeture ---------- */

/**
 * Ferme le ticket de ce salon.
 * Renvoie false si le salon n'est pas un ticket ouvert.
 */
async function fermerTicket(salon, membre, client) {
    const serveur = salon.guild;
    const reglages = lireServeur(serveur.id);
    const L = reglages.langue;

    const tickets = lireTickets(serveur.id);
    const ticket = tickets.ouverts[salon.id];

    if (!ticket || fermeturesEnCours.has(salon.id)) return false;
    fermeturesEnCours.add(salon.id);

    try {
        const fermeLe = Date.now();
        const delai = client.config.tickets.delaiFermeture;

        const texteFermeture = (reste) => [
            membre ? t("tickets.fermePar", { membre: `<@${membre.id}>` }, L) : null,
            reste > 0 ? t("tickets.suppressionDans", { secondes: reste }, L) : t("tickets.suppressionMaintenant", {}, L),
        ].filter(Boolean).join("\n");

        // 1) Annonce dans le salon
        const embed = new EmbedBuilder()
            .setColor(client.config.couleurs.erreur)
            .setTitle(t("tickets.titreFerme", {}, L))
            .setDescription(texteFermeture(delai));

        const annonce = await salon.send({ embeds: [embed] }).catch(() => null);

        // 2) Le ticket passe des "ouverts" à l'historique
        delete tickets.ouverts[salon.id];
        tickets.historique = [
            ...(tickets.historique ?? []),
            { ...ticket, fermeLe, fermePar: membre?.id ?? null },
        ].slice(-TAILLE_HISTORIQUE);
        ecrireTickets(serveur.id, tickets);

        // 3) Transcription, logs et copie à l'auteur
        const transcription = await archiver(salon, ticket, membre, fermeLe, client, reglages);

        // 4) Version premium (note de satisfaction, stats…)
        await declencher("fermeture", { client, salon, ticket, membre, reglages, transcription });

        // 5) Compte à rebours, puis suppression du salon
        for (let reste = delai - 1; reste >= 1; reste--) {
            await attendre(1000);
            if (annonce) {
                embed.setDescription(texteFermeture(reste));
                await annonce.edit({ embeds: [embed] }).catch(() => {});
            }
        }
        if (delai > 0) await attendre(1000);

        await salon.delete().catch(async (erreur) => {
            console.error(erreur);
            await salon.send(t("tickets.erreurSuppression", {}, L)).catch(() => {});
        });

        return true;
    } finally {
        fermeturesEnCours.delete(salon.id);
    }
}

module.exports = { fermerTicket, estEnFermeture };