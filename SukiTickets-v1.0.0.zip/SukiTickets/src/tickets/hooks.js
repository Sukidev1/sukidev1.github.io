// sukitickets/src/tickets/hooks.js

/* ===================================================
   Points de branchement pour la version premium
   Le code standard appelle declencher("nom", {...})
   à certains moments clés. Si le fichier
   src/premium/hooks.js existe et contient une
   fonction de ce nom, elle est exécutée.
   Sans premium, rien ne se passe.

   Points de branchement disponibles :
     avantOuverture  → avant la création d'un ticket.
                       Si elle renvoie true, c'est le premium
                       qui s'occupe de la suite (ex : formulaire).
     apresCreation      → juste après la création du salon.
     apresPriseEnCharge → quand un membre du staff prend le ticket.
     fermeture          → quand un ticket se ferme, avant que
                          le salon soit supprimé.
   =================================================== */

const fs = require("node:fs");
const path = require("node:path");
const { t } = require("../utils/langue");

const FICHIER_PREMIUM = path.join(__dirname, "..", "premium", "hooks.js");

// Chargé au premier besoin (et pas au démarrage), pour que le premium
// puisse utiliser librement les fichiers de la version gratuite
let hooksPremium = null;

function chargerHooks() {
    if (hooksPremium === null) {
        hooksPremium = fs.existsSync(FICHIER_PREMIUM) ? require(FICHIER_PREMIUM) : {};
    }
    return hooksPremium;
}

/**
 * Lance la fonction premium "nom" si elle existe.
 * Renvoie ce qu'elle renvoie (ou undefined).
 * Une erreur dans le premium ne fait jamais planter le bot.
 */
async function declencher(nom, donnees) {
    const fonction = chargerHooks()[nom];
    if (typeof fonction !== "function") return undefined;

    try {
        return await fonction(donnees);
    } catch (erreur) {
        console.error(t("console.erreurHook", { nom }), erreur);
        return undefined;
    }
}

module.exports = { declencher };