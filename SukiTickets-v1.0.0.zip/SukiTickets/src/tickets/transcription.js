// sukitickets/src/tickets/transcription.js

/* ===================================================
   Transcription d'un ticket
   creerTranscription(salon, ticket, infos, langue)
   récupère tous les messages du salon et fabrique
   une jolie page HTML (style nuit étoilée pastel),
   lisible dans n'importe quel navigateur.

   Renvoie { html, nombreMessages }.

   Note : les images envoyées dans le ticket sont des
   liens vers Discord. Discord rend ces liens
   temporaires : après un certain temps, les images
   peuvent ne plus s'afficher (le texte, lui, reste).
   =================================================== */

const { t } = require("../utils/langue");

// Limite de sécurité : au-delà, on ne garde que les 5 000 premiers messages
const MAX_MESSAGES = 5000;

/* ---------- Récupération des messages ---------- */

async function recupererMessages(salon) {
    const messages = [];
    let avant;

    while (messages.length < MAX_MESSAGES) {
        const lot = await salon.messages.fetch({ limit: 100, before: avant });
        if (lot.size === 0) break;

        messages.push(...lot.values());
        avant = lot.last().id;

        if (lot.size < 100) break;
    }

    // Discord les donne du plus récent au plus ancien : on remet dans l'ordre
    return messages.reverse();
}

/* ---------- Mise en forme du texte ---------- */

const echapper = (texte) => String(texte ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");

/** Transforme le Markdown de Discord (gras, code, mentions…) en HTML */
function formaterTexte(texte, message, serveur) {
    let html = echapper(texte);

    // Les blocs de code sont mis de côté : rien ne doit être transformé à l'intérieur
    const codes = [];
    const garder = (morceau) => `\u0000${codes.push(morceau) - 1}\u0000`;
    html = html.replace(/```(?:[\w-]+\n)?([\s\S]*?)```\n?/g, (_, code) => garder(`<pre>${code.replace(/\n$/, "")}</pre>`));
    html = html.replace(/`([^`\n]+)`/g, (_, code) => garder(`<code>${code}</code>`));

    // Liens (avant les emojis, pour ne pas toucher aux adresses des images)
    html = html.replace(/(https?:\/\/[^\s<]+)/g, '<a href="$1" target="_blank" rel="noopener">$1</a>');

    // Mentions de membres, de rôles et de salons
    html = html.replace(/&lt;@!?(\d+)&gt;/g, (_, id) => {
        const utilisateur = message?.mentions?.users?.get(id) ?? serveur?.client?.users?.cache?.get(id);
        return `<span class="mention">@${echapper(utilisateur?.globalName ?? utilisateur?.username ?? id)}</span>`;
    });
    html = html.replace(/&lt;@&amp;(\d+)&gt;/g, (_, id) => {
        const role = message?.mentions?.roles?.get(id) ?? serveur?.roles?.cache?.get(id);
        return `<span class="mention">@${echapper(role?.name ?? id)}</span>`;
    });
    html = html.replace(/&lt;#(\d+)&gt;/g, (_, id) => {
        const salon = serveur?.channels?.cache?.get(id);
        return `<span class="mention">#${echapper(salon?.name ?? id)}</span>`;
    });

    // Emojis personnalisés
    html = html.replace(/&lt;(a?):(\w+):(\d+)&gt;/g, (_, anime, nom, id) =>
        `<img class="emoji" alt=":${nom}:" src="https://cdn.discordapp.com/emojis/${id}.${anime ? "gif" : "png"}">`);

    // Gras, souligné, italique, barré
    html = html
        .replace(/\*\*(.+?)\*\*/g, "<b>$1</b>")
        .replace(/__(.+?)__/g, "<u>$1</u>")
        .replace(/(^|[^*])\*([^*\n]+)\*/g, "$1<i>$2</i>")
        .replace(/~~(.+?)~~/g, "<s>$1</s>");

    // Retours à la ligne, puis on remet les blocs de code
    return html
        .replace(/\n/g, "<br>")
        .replace(/\u0000(\d+)\u0000/g, (_, i) => codes[Number(i)]);
}

/* ---------- Un message ---------- */

function messageEnHtml(message, serveur, formatDate, L) {
    const auteur = message.author;
    const nom = message.member?.displayName ?? auteur.globalName ?? auteur.username;
    const couleur = message.member?.displayHexColor && message.member.displayHexColor !== "#000000"
        ? message.member.displayHexColor
        : "#fdf7ff";
    const avatar = auteur.displayAvatarURL?.({ size: 64, extension: "png" }) ?? "";

    const morceaux = [];

    if (message.content) morceaux.push(`<div class="texte">${formaterTexte(message.content, message, serveur)}</div>`);

    // Embeds (messages du bot, liens…)
    for (const embed of message.embeds ?? []) {
        const champs = (embed.fields ?? []).map((champ) =>
            `<div class="champ"><div class="nom-champ">${formaterTexte(champ.name, message, serveur)}</div><div>${formaterTexte(champ.value, message, serveur)}</div></div>`).join("");

        morceaux.push(`
            <div class="embed" style="border-color:${embed.hexColor ?? "#b294ff"}">
                ${embed.title ? `<div class="titre-embed">${formaterTexte(embed.title, message, serveur)}</div>` : ""}
                ${embed.description ? `<div>${formaterTexte(embed.description, message, serveur)}</div>` : ""}
                ${champs ? `<div class="champs">${champs}</div>` : ""}
                ${embed.footer?.text ? `<div class="pied-embed">${echapper(embed.footer.text)}</div>` : ""}
            </div>`);
    }

    // Pièces jointes : les images s'affichent, les autres fichiers deviennent des liens
    for (const fichier of message.attachments?.values() ?? []) {
        const estImage = (fichier.contentType ?? "").startsWith("image/");
        morceaux.push(estImage
            ? `<a href="${echapper(fichier.url)}" target="_blank" rel="noopener"><img class="image" src="${echapper(fichier.url)}" alt="${echapper(fichier.name)}"></a>`
            : `<a class="fichier" href="${echapper(fichier.url)}" target="_blank" rel="noopener">📎 ${t("transcription.pieceJointe", {}, L)} : ${echapper(fichier.name)}</a>`);
    }

    if (morceaux.length === 0) morceaux.push(`<div class="texte vide">${t("transcription.vide", {}, L)}</div>`);

    return `
        <div class="message">
            <img class="avatar" src="${echapper(avatar)}" alt="">
            <div class="corps">
                <div class="entete">
                    <span class="auteur" style="color:${couleur}">${echapper(nom)}</span>
                    ${auteur.bot ? '<span class="badge">BOT</span>' : ""}
                    <span class="date">${formatDate.format(message.createdAt)}</span>
                </div>
                ${morceaux.join("")}
            </div>
        </div>`;
}

/* ---------- La page complète ---------- */

/**
 * infos = { serveur, categorie, auteur, prisEnCharge, fermePar, ouvertLe, fermeLe }
 * (des textes déjà prêts à afficher, sauf les dates qui sont des timestamps)
 */
async function creerTranscription(salon, ticket, infos, langue) {
    const L = langue;
    const messages = await recupererMessages(salon);
    const formatDate = new Intl.DateTimeFormat(t("transcription.locale", {}, L), { dateStyle: "short", timeStyle: "short" });
    const numero = String(ticket.numero).padStart(4, "0");

    const ligneInfo = (cle, valeur) =>
        `<div class="info"><span>${t(`transcription.${cle}`, {}, L)}</span><b>${echapper(valeur)}</b></div>`;

    const html = `<!doctype html>
<html lang="${L}">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${echapper(t("transcription.titre", { numero }, L))}</title>
<style>
    :root { --fond:#140f2b; --carte:rgba(255,255,255,.06); --bord:rgba(255,255,255,.12); --texte:#fdf7ff; --doux:#cfc3ee; --rose:#ffbcdc; --lavande:#d6c2ff; }
    * { box-sizing:border-box; }
    body { margin:0; font-family:"Segoe UI",system-ui,sans-serif; color:var(--texte);
           background:linear-gradient(180deg,#140f2b,#2a1f57 60%,#5b4389) fixed; min-height:100vh; }
    .page { max-width:900px; margin:0 auto; padding:32px 16px 60px; }
    h1 { font-size:28px; margin:0 0 6px; background:linear-gradient(120deg,#ffbcdc,#d6c2ff,#b3e2ff); -webkit-background-clip:text; background-clip:text; color:transparent; }
    .resume { background:var(--carte); border:1px solid var(--bord); border-radius:20px; padding:20px; margin:18px 0 26px;
              display:grid; grid-template-columns:repeat(auto-fill,minmax(200px,1fr)); gap:12px; }
    .info span { display:block; font-size:12px; text-transform:uppercase; letter-spacing:.05em; color:var(--lavande); }
    .info b { font-size:15px; }
    .message { display:flex; gap:14px; padding:12px 10px; border-radius:14px; }
    .message:hover { background:rgba(255,255,255,.03); }
    .avatar { width:42px; height:42px; border-radius:50%; flex-shrink:0; background:#2a1f57; }
    .corps { min-width:0; flex:1; }
    .entete { display:flex; align-items:baseline; gap:8px; flex-wrap:wrap; }
    .auteur { font-weight:700; }
    .badge { font-size:10px; font-weight:800; background:#9d7bea; color:#fff; padding:1px 6px; border-radius:6px; }
    .date { font-size:12px; color:#8f84b3; }
    .texte { margin-top:3px; line-height:1.5; overflow-wrap:anywhere; }
    .vide { color:#8f84b3; font-style:italic; }
    .mention { background:rgba(214,194,255,.18); color:var(--lavande); padding:0 4px; border-radius:4px; }
    a { color:#8fd3ff; }
    code { background:rgba(0,0,0,.35); padding:1px 5px; border-radius:5px; font-family:Consolas,monospace; }
    pre { background:rgba(0,0,0,.35); padding:10px; border-radius:8px; overflow:auto; font-family:Consolas,monospace; }
    .emoji { width:20px; height:20px; vertical-align:-4px; }
    .embed { margin-top:6px; border-left:4px solid; background:rgba(255,255,255,.05); border-radius:8px; padding:10px 14px; max-width:560px; }
    .titre-embed { font-weight:700; margin-bottom:4px; }
    .champs { display:grid; grid-template-columns:repeat(auto-fill,minmax(150px,1fr)); gap:8px; margin-top:8px; }
    .nom-champ { font-weight:700; font-size:13px; }
    .pied-embed { margin-top:8px; font-size:12px; color:#8f84b3; }
    .image { display:block; max-width:min(400px,100%); border-radius:10px; margin-top:6px; }
    .fichier { display:inline-block; margin-top:6px; padding:6px 12px; border-radius:10px; background:var(--carte); border:1px solid var(--bord); text-decoration:none; }
    .fin { text-align:center; color:var(--doux); font-size:13px; margin-top:30px; }
</style>
</head>
<body>
<div class="page">
    <h1>${echapper(t("transcription.titre", { numero }, L))}</h1>
    <div class="resume">
        ${ligneInfo("serveur", infos.serveur)}
        ${ligneInfo("categorie", infos.categorie)}
        ${ligneInfo("auteur", infos.auteur)}
        ${ligneInfo("prisEnCharge", infos.prisEnCharge ?? t("transcription.personne", {}, L))}
        ${ligneInfo("fermePar", infos.fermePar)}
        ${ligneInfo("ouvertLe", formatDate.format(new Date(infos.ouvertLe)))}
        ${ligneInfo("fermeLe", formatDate.format(new Date(infos.fermeLe)))}
        ${ligneInfo("messages", String(messages.length))}
    </div>
    ${messages.map((message) => messageEnHtml(message, salon.guild, formatDate, L)).join("")}
    <p class="fin">${t("transcription.genere", {}, L)}</p>
</div>
</body>
</html>`;

    return { html, nombreMessages: messages.length };
}

module.exports = { creerTranscription };