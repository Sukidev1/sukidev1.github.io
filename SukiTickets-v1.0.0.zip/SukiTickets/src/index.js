// sukitickets/src/index.js

/* ===================================================
   SukiTickets — point d'entrée du bot
   Vérifie config.json, charge les commandes,
   les événements, les boutons et menus, puis
   lance la connexion à Discord.
   =================================================== */

require("dotenv").config();

const fs = require("node:fs");
const path = require("node:path");
const { Client, Collection, GatewayIntentBits } = require("discord.js");

const config = require("../config.json");
const { t } = require("./utils/langue");
const { verifierStructure, afficherResultat } = require("./utils/verifierConfig");
const { chargerCommandes } = require("./handlers/commandHandler");
const { chargerEvenements } = require("./handlers/eventHandler");
const { chargerComposants } = require("./handlers/componentHandler");


/* ---------- Vérification du token ---------- */

if (!process.env.TOKEN) {
    console.error(t("console.tokenManquant"));
    process.exit(1);
}


/* ---------- Vérification de config.json (langue, couleurs…) ---------- */

const configOk = afficherResultat(verifierStructure(config));

if (!configOk) {
    console.error(t("config.arret"));
    process.exit(1);
}


/* ---------- Création du client ---------- */

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,           // serveurs, salons, rôles
        GatewayIntentBits.GuildMessages,    // messages dans les tickets
        GatewayIntentBits.MessageContent,   // contenu des messages (pour les transcriptions)
    ],
});

// On range ici tout ce dont le reste du bot aura besoin
client.config = config;
client.commands = new Collection();

// Version premium : activée uniquement si le dossier src/premium existe
client.estPremium = fs.existsSync(path.join(__dirname, "premium"));


/* ---------- Chargement ---------- */

chargerCommandes(client);
chargerEvenements(client);
chargerComposants(client);


/* ---------- Sécurité : le bot ne plante pas sur une erreur inattendue ---------- */

process.on("unhandledRejection", (erreur) => {
    console.error(t("console.erreurNonGeree"), erreur);
});

process.on("uncaughtException", (erreur) => {
    console.error(t("console.exceptionNonGeree"), erreur);
});


/* ---------- Connexion ---------- */

client.login(process.env.TOKEN).catch((erreur) => {
    console.error(t("console.connexionImpossible"));
    console.error(erreur.message);
    process.exit(1);
});