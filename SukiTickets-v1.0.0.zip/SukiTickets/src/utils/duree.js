// sukitickets/src/utils/duree.js

/* ===================================================
   Durée lisible
   formaterDuree(ms, langue) :
     30 s      → "moins d'une minute"
     12 min    → "12 min"
     1 h 05    → "1 h 5 min"
     2 j 3 h   → "2 j 3 h"
   =================================================== */

const { t } = require("./langue");

function formaterDuree(ms, langue) {
    const minutesTotales = Math.floor(ms / 60000);

    if (minutesTotales < 1) return t("duree.moinsMinute", {}, langue);

    const j = Math.floor(minutesTotales / 1440);
    const h = Math.floor((minutesTotales % 1440) / 60);
    const m = minutesTotales % 60;

    if (j > 0) return t("duree.jours", { j, h }, langue);
    if (h > 0) return t("duree.heures", { h, m }, langue);
    return t("duree.minutes", { m }, langue);
}

module.exports = { formaterDuree };