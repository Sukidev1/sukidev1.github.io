// sukitickets/src/utils/staff.js

/* ===================================================
   Staff
   - estStaff(membre, reglages) : le membre a-t-il un
     rôle staff (ou est-il administrateur) ?
   - verifierCommandeTicket(interaction) : pour les
     commandes /add, /remove, /rename. Vérifie qu'on
     est dans un ticket ouvert et que la personne est
     staff. Répond l'erreur si besoin et renvoie null.
   =================================================== */

const { PermissionFlagsBits, MessageFlags } = require("discord.js");
const { t } = require("./langue");
const { lireServeur, lireTickets } = require("./donnees");

function estStaff(membre, reglages) {
    if (membre?.permissions?.has(PermissionFlagsBits.Administrator)) return true;
    return reglages.rolesStaff.some((id) => membre?.roles?.cache.has(id));
}

async function verifierCommandeTicket(interaction) {
    const reglages = lireServeur(interaction.guildId);
    const L = reglages.langue;
    const ticket = lireTickets(interaction.guildId).ouverts[interaction.channelId];

    if (!ticket) {
        await interaction.reply({ content: t("tickets.pasUnTicket", {}, L), flags: MessageFlags.Ephemeral });
        return null;
    }

    if (!estStaff(interaction.member, reglages)) {
        await interaction.reply({ content: t("gestion.reserveStaff", {}, L), flags: MessageFlags.Ephemeral });
        return null;
    }

    return { ticket, reglages, L };
}

module.exports = { estStaff, verifierCommandeTicket };