// sukitickets/src/utils/verifierConfig.js

/* ===================================================
   Vérifications
   1) verifierStructure : au démarrage, vérifie que
      config.json est correct (langue, couleurs,
      catégories par défaut…). En cas d'erreur,
      le bot s'arrête avec un message clair.
   2) etatServeur : vérifie la configuration d'un
      serveur (faite avec /setup) : rôles, catégorie,
      salon de logs et permissions du bot.
   =================================================== */

const { ChannelType, PermissionFlagsBits } = require("discord.js");
const { t, languesDisponibles } = require("./langue");

const FORMAT_COULEUR = /^#[0-9A-Fa-f]{6}$/;

// Permissions dont le bot a besoin pour gérer les tickets
const PERMISSIONS_REQUISES = [
    "ViewChannel",
    "ManageChannels",
    "ManageRoles",
    "ManageMessages",   // nécessaire pour donner ce droit au staff dans les tickets
    "SendMessages",
    "EmbedLinks",
    "AttachFiles",
    "ReadMessageHistory",
];

/* ---------- 1) Vérification de config.json ---------- */

function verifierStructure(config) {
    const erreurs = [];
    const avertissements = [];

    // Langue par défaut
    const langues = languesDisponibles();
    if (!langues.includes(config.langue)) {
        erreurs.push(t("config.langueInconnue", { langue: config.langue, langues: langues.join(", ") }, "fr"));
    }

    // Couleurs
    for (const [nom, valeur] of Object.entries(config.couleurs ?? {})) {
        if (!FORMAT_COULEUR.test(valeur)) erreurs.push(t("config.couleurInvalide", { nom }));
    }

    // Réglages des tickets
    const max = config.tickets?.maxParMembre;
    if (!Number.isInteger(max) || max < 1) erreurs.push(t("config.maxInvalide"));

    const delai = config.tickets?.delaiFermeture;
    if (typeof delai !== "number" || delai < 0) erreurs.push(t("config.delaiInvalide"));

    // Catégories proposées par défaut aux nouveaux serveurs
    const categories = config.categoriesParDefaut ?? [];
    if (categories.length === 0) erreurs.push(t("config.categoriesVides"));
    if (categories.length > 25) erreurs.push(t("config.tropDeCategories", { nombre: categories.length }));

    const idsVus = new Set();
    categories.forEach((categorie, i) => {
        if (!categorie.id || !categorie.nom) {
            erreurs.push(t("config.categorieIncomplete", { numero: i + 1 }));
            return;
        }
        if (idsVus.has(categorie.id)) erreurs.push(t("config.categorieDoublon", { id: categorie.id }));
        idsVus.add(categorie.id);
    });

    return { erreurs, avertissements };
}

/**
 * Affiche les erreurs et avertissements dans la console.
 * Renvoie true si tout est bon (aucune erreur).
 */
function afficherResultat({ erreurs, avertissements }) {
    if (erreurs.length > 0) {
        console.error(`\n${t("config.titreErreurs")}`);
        erreurs.forEach((e) => console.error(`   • ${e}`));
    }

    if (avertissements.length > 0) {
        console.warn(`\n${t("config.titreAvertissements")}`);
        avertissements.forEach((a) => console.warn(`   • ${a}`));
    }

    if (erreurs.length > 0 || avertissements.length > 0) console.log("");

    return erreurs.length === 0;
}

/* ---------- 2) État de la configuration d'un serveur ---------- */

/**
 * Regarde si ce qui a été choisi avec /setup existe encore
 * et si le bot a les bonnes permissions.
 */
function etatServeur(serveur, reglages) {
    // Rôles staff encore présents sur le serveur
    const roles = reglages.rolesStaff.filter((id) => serveur.roles.cache.has(id));

    // Catégorie des tickets
    const categorie = reglages.categorieTickets ? serveur.channels.cache.get(reglages.categorieTickets) : null;
    let etatCategorie = "nonDefini";
    if (reglages.categorieTickets && !categorie) etatCategorie = "introuvable";
    else if (categorie && categorie.type !== ChannelType.GuildCategory) etatCategorie = "mauvaisType";
    else if (categorie) etatCategorie = "ok";

    // Salon de logs
    const logs = reglages.salonLogs ? serveur.channels.cache.get(reglages.salonLogs) : null;
    let etatLogs = "nonDefini";
    if (reglages.salonLogs && !logs) etatLogs = "introuvable";
    else if (logs && logs.type !== ChannelType.GuildText) etatLogs = "mauvaisType";
    else if (logs) etatLogs = "ok";

    // Le salon de logs est-il visible par tout le monde ? (pas bloquant, juste un avertissement)
    const logsPublic = etatLogs === "ok" &&
        logs.permissionsFor?.(serveur.roles.everyone)?.has(PermissionFlagsBits.ViewChannel) === true;

    // Permissions du bot
    const moi = serveur.members.me;
    const permissionsManquantes = PERMISSIONS_REQUISES.filter((nom) => !moi?.permissions.has(PermissionFlagsBits[nom]));

    const pret = roles.length > 0 && etatCategorie === "ok" && etatLogs === "ok" && permissionsManquantes.length === 0;

    return { roles, etatCategorie, etatLogs, logsPublic, permissionsManquantes, pret };
}

module.exports = { verifierStructure, afficherResultat, etatServeur, PERMISSIONS_REQUISES };