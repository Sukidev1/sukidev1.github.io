// sukitickets/src/utils/marque.js

/* ===================================================
   Marque SukiDev
   - Liens et prix de la version premium
   - piedDePage(client, langue) : le texte affiché en
     bas de chaque embed du bot.
       Version gratuite → « SukiTickets ✦ · Passe en Premium avec /premium »
       Version premium  → « SukiTickets Premium ✦ »
   =================================================== */

const { t } = require("./langue");

const PRIX_PREMIUM = "5,99 €";
const LIEN_PRODUIT = "https://sukidev1.github.io/sukitickets.html";
const LIEN_SITE = "https://sukidev1.github.io";

function piedDePage(client, langue) {
    return client.estPremium
        ? t("general.piedPremium", {}, langue)
        : t("general.piedGratuit", {}, langue);
}

module.exports = { PRIX_PREMIUM, LIEN_PRODUIT, LIEN_SITE, piedDePage };