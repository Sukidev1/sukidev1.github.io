// sukitickets/src/utils/emoji.js

/* ===================================================
   Emojis
   - lireEmoji(texte)  → vérifie qu'un texte tapé par
     un admin est bien un emoji utilisable par Discord
     (emoji classique 🛟 ou emoji du serveur <:nom:id>)
   - emojiComposant(emoji) → le convertit au format
     attendu par les menus et boutons de Discord
   =================================================== */

// Emoji personnalisé d'un serveur : <:nom:123…> ou <a:nom:123…> (animé)
const EMOJI_PERSO = /^<(a?):(\w{2,32}):(\d{17,20})>$/;

// UN SEUL emoji classique : drapeau (🇫🇷), touche (1️⃣) ou pictogramme,
// avec ses variantes (teinte de peau 👋🏽, combinaisons comme 👨‍💻)
const EMOJI_CLASSIQUE = /^(?:\p{Regional_Indicator}{2}|[#*0-9]️?⃣|\p{Extended_Pictographic}️?\p{Emoji_Modifier}?(?:‍\p{Extended_Pictographic}️?\p{Emoji_Modifier}?)*)$/u;

/**
 * Renvoie { valide, emoji } :
 *  - texte vide      → { valide: true, emoji: null }
 *  - emoji correct   → { valide: true, emoji: "🛟" }
 *  - autre chose     → { valide: false, emoji: null }
 */
function lireEmoji(texte) {
    const propre = (texte ?? "").trim();

    if (!propre) return { valide: true, emoji: null };
    if (EMOJI_PERSO.test(propre)) return { valide: true, emoji: propre };
    if (EMOJI_CLASSIQUE.test(propre)) return { valide: true, emoji: propre };

    return { valide: false, emoji: null };
}

/** "🛟" → { name: "🛟" } ; "<:chat:123>" → { name: "chat", id: "123", animated: false } */
function emojiComposant(emoji) {
    const perso = EMOJI_PERSO.exec(emoji ?? "");
    if (perso) return { name: perso[2], id: perso[3], animated: perso[1] === "a" };
    return { name: emoji };
}

module.exports = { lireEmoji, emojiComposant };