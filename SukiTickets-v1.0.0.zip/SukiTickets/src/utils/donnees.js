// sukitickets/src/utils/donnees.js

/* ===================================================
   Données enregistrées par le bot (dossier data/)

   data/serveurs.json → réglages de chaque serveur
     (rôles staff, catégorie, salon de logs, langue,
      catégories de tickets, menus envoyés avec /panel…)
   data/tickets.json  → tickets de chaque serveur
     (compteur pour les numéros, tickets ouverts…)

   Les fichiers et le dossier sont créés
   automatiquement au premier besoin.

   - lireServeur(id)             → réglages du serveur
   - modifierServeur(id, {...})  → change des réglages
   - lireTickets(id)             → tickets du serveur
   - ecrireTickets(id, tickets)  → enregistre les tickets
   =================================================== */

const fs = require("node:fs");
const path = require("node:path");

const config = require("../../config.json");
const { t } = require("./langue");

const DOSSIER_DONNEES = path.join(__dirname, "..", "..", "data");

/**
 * Petit "magasin" de données : un fichier JSON gardé en mémoire,
 * avec un objet par serveur.
 */
function creerMagasin(nomFichier) {
    const fichier = path.join(DOSSIER_DONNEES, nomFichier);
    let donnees = null;

    // Lit le fichier une seule fois, au premier besoin
    function charger() {
        if (donnees) return donnees;

        if (!fs.existsSync(fichier)) {
            donnees = {};
            return donnees;
        }

        try {
            donnees = JSON.parse(fs.readFileSync(fichier, "utf8"));
        } catch {
            // Fichier abîmé : on garde une copie au lieu de l'écraser, pour ne rien perdre
            const copie = nomFichier.replace(".json", `.corrompu-${Date.now()}.json`);
            fs.copyFileSync(fichier, path.join(DOSSIER_DONNEES, copie));
            console.warn(t("console.donneesCorrompues", { fichier: nomFichier, copie }));
            donnees = {};
        }

        return donnees;
    }

    // Écrit dans un fichier temporaire puis le renomme : le fichier n'est jamais à moitié écrit
    function sauvegarder() {
        fs.mkdirSync(DOSSIER_DONNEES, { recursive: true });
        const temporaire = `${fichier}.tmp`;
        fs.writeFileSync(temporaire, JSON.stringify(donnees, null, 2));
        fs.renameSync(temporaire, fichier);
    }

    return {
        lire(id, parDefaut) {
            return { ...parDefaut, ...(charger()[id] ?? {}) };
        },
        ecrire(id, valeur) {
            charger()[id] = valeur;
            sauvegarder();
            return valeur;
        },
    };
}

const magasinServeurs = creerMagasin("serveurs.json");
const magasinTickets = creerMagasin("tickets.json");

/* ---------- Réglages des serveurs ---------- */

/** Réglages d'un serveur qui n'a encore rien configuré */
function reglagesParDefaut() {
    return {
        langue: config.langue,
        rolesStaff: [],
        categorieTickets: null,
        salonLogs: null,
        categories: structuredClone(config.categoriesParDefaut),
        panneaux: [], // menus de tickets envoyés avec /panel
    };
}

function lireServeur(id) {
    return magasinServeurs.lire(id, reglagesParDefaut());
}

function modifierServeur(id, changements) {
    return magasinServeurs.ecrire(id, { ...lireServeur(id), ...changements });
}

/* ---------- Tickets ---------- */

/**
 * {
 *   compteur: 12,                    → numéro du dernier ticket créé
 *   ouverts: {
 *     "<id du salon>": { numero, auteur, categorie, ouvertLe, prisEnCharge, messageAccueil }
 *   },
 *   historique: [ …les 500 derniers tickets fermés (avec fermeLe et fermePar)… ]
 * }
 */
function lireTickets(id) {
    return magasinTickets.lire(id, { compteur: 0, ouverts: {} });
}

function ecrireTickets(id, tickets) {
    return magasinTickets.ecrire(id, tickets);
}

module.exports = { lireServeur, modifierServeur, lireTickets, ecrireTickets };