// sukitickets/src/composants/ticket.js

/* ===================================================
   Boutons et menus des tickets
   Identifiants qui commencent par "ticket:"
     ticket:ouvrir           → un membre choisit une catégorie
                               dans le menu envoyé par /panel
     ticket:prendre          → bouton « Prendre en charge » (staff)
     ticket:fermer           → bouton « Fermer » (demande confirmation)
     ticket:fermer-confirmer → « Oui, fermer »
     ticket:fermer-annuler   → « Annuler »
   =================================================== */

const { MessageFlags, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require("discord.js");

const { t } = require("../utils/langue");
const { lireServeur, lireTickets, ecrireTickets } = require("../utils/donnees");
const { etatServeur } = require("../utils/verifierConfig");
const { creerTicket, ticketsOuvertsDe, construireAccueil } = require("../tickets/creation");
const { fermerTicket, estEnFermeture } = require("../tickets/fermeture");
const { declencher } = require("../tickets/hooks");
const { envoyerLog } = require("../tickets/logs");
const { estStaff } = require("../utils/staff");

const prive = (content) => ({ content, flags: MessageFlags.Ephemeral });

// Membres dont le ticket est en train d'être créé (évite les doubles clics)
const enCreation = new Set();

/* ---------- Ouverture d'un ticket ---------- */

async function ouvrir(interaction, client) {
    const serveur = interaction.guild;
    const reglages = lireServeur(serveur.id);
    const L = reglages.langue;
    const cle = `${serveur.id}:${interaction.user.id}`;

    // Remet le menu à zéro (pour le prochain membre) puis répond en privé
    const refuser = async (texte) => {
        await interaction.update({ components: interaction.message.components });
        return interaction.followUp(prive(texte));
    };

    // 1) La configuration doit toujours être bonne (un salon a pu être supprimé)
    if (!etatServeur(serveur, reglages).pret) return refuser(t("tickets.indisponible", {}, L));

    // 2) La catégorie doit exister
    const categorie = reglages.categories.find((c) => c.id === interaction.values[0]);
    if (!categorie) return refuser(t("panel.categorieIntrouvable", {}, L));

    // 3) Pas de double clic
    if (enCreation.has(cle)) return refuser(t("tickets.enCours", {}, L));

    // 4) Limite de tickets ouverts par membre
    const ouverts = ticketsOuvertsDe(serveur, interaction.user.id);
    const max = client.config.tickets.maxParMembre;
    if (ouverts.length >= max) {
        return refuser(t("tickets.dejaOuvert", {
            nombre: ouverts.length,
            salons: ouverts.map((id) => `<#${id}>`).join(", "),
        }, L));
    }

    enCreation.add(cle);
    try {
        // 5) Version premium : peut prendre la main (ex : formulaire à remplir avant)
        const gereParPremium = await declencher("avantOuverture", { interaction, client, categorie, reglages });
        if (gereParPremium === true) return;

        // 6) Création du ticket
        await interaction.update({ components: interaction.message.components });
        await creerTicket(interaction, client, categorie);
    } finally {
        enCreation.delete(cle);
    }
}

/* ---------- Prise en charge (staff) ---------- */

async function prendre(interaction, client) {
    const serveur = interaction.guild;
    const reglages = lireServeur(serveur.id);
    const L = reglages.langue;

    const tickets = lireTickets(serveur.id);
    const ticket = tickets.ouverts[interaction.channelId];

    if (!ticket) return interaction.reply(prive(t("tickets.pasUnTicket", {}, L)));
    if (!estStaff(interaction.member, reglages)) return interaction.reply(prive(t("tickets.reserveStaff", {}, L)));
    if (ticket.prisEnCharge) {
        return interaction.reply(prive(t("tickets.dejaPris", { staff: `<@${ticket.prisEnCharge}>` }, L)));
    }

    ticket.prisEnCharge = interaction.user.id;
    ticket.prisEnChargeLe = Date.now();
    ecrireTickets(serveur.id, tickets);

    // Le message d'accueil affiche maintenant qui s'occupe du ticket (et le bouton se grise)
    const categorie = reglages.categories.find((c) => c.id === ticket.categorie);
    await interaction.update(construireAccueil(ticket, categorie, reglages, client));

    // Annonce visible par tous dans le ticket
    await interaction.channel.send({
        embeds: [
            new EmbedBuilder()
                .setColor(client.config.couleurs.succes)
                .setDescription(t("tickets.annoncePriseEnCharge", { staff: `<@${interaction.user.id}>` }, L)),
        ],
    });

    // Résumé dans le salon de logs
    await envoyerLog(serveur, client, {
        titre: t("logs.titrePriseEnCharge", {}, L),
        couleur: client.config.couleurs.succes,
        champs: [
            { name: t("logs.champTicket", {}, L), value: `#${String(ticket.numero).padStart(4, "0")}` },
            { name: t("logs.champPrisEnCharge", {}, L), value: `<@${interaction.user.id}>` },
            { name: t("logs.champSalon", {}, L), value: `<#${interaction.channelId}>` },
        ],
    });

    await declencher("apresPriseEnCharge", { interaction, client, ticket, reglages });
}

/* ---------- Fermeture (auteur ou staff) ---------- */

async function demanderFermeture(interaction) {
    const reglages = lireServeur(interaction.guildId);
    const L = reglages.langue;
    const ticket = lireTickets(interaction.guildId).ouverts[interaction.channelId];

    if (!ticket) return interaction.reply(prive(t("tickets.pasUnTicket", {}, L)));
    if (ticket.auteur !== interaction.user.id && !estStaff(interaction.member, reglages)) {
        return interaction.reply(prive(t("tickets.reserveFermeture", {}, L)));
    }
    if (estEnFermeture(interaction.channelId)) return interaction.reply(prive(t("tickets.fermetureEnCours", {}, L)));

    // Demande de confirmation, visible seulement par la personne qui a cliqué
    const boutons = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId("ticket:fermer-confirmer")
            .setLabel(t("tickets.boutonConfirmer", {}, L))
            .setEmoji("🔒")
            .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
            .setCustomId("ticket:fermer-annuler")
            .setLabel(t("tickets.boutonAnnuler", {}, L))
            .setStyle(ButtonStyle.Secondary),
    );

    return interaction.reply({
        content: t("tickets.confirmerFermeture", {}, L),
        components: [boutons],
        flags: MessageFlags.Ephemeral,
    });
}

async function confirmerFermeture(interaction, client) {
    const reglages = lireServeur(interaction.guildId);
    const L = reglages.langue;
    const ticket = lireTickets(interaction.guildId).ouverts[interaction.channelId];

    // Le ticket a pu être fermé entre-temps par quelqu'un d'autre
    if (!ticket) return interaction.update({ content: t("tickets.pasUnTicket", {}, L), components: [] });
    if (estEnFermeture(interaction.channelId)) {
        return interaction.update({ content: t("tickets.fermetureEnCours", {}, L), components: [] });
    }

    await interaction.update({ content: t("tickets.fermetureConfirmee", {}, L), components: [] });
    await fermerTicket(interaction.channel, interaction.user, client);
}

/* ---------- Aiguillage ---------- */

module.exports = {
    prefixe: "ticket",

    async execute(interaction, client) {
        const action = interaction.customId.split(":")[1];
        const L = lireServeur(interaction.guildId).langue;

        switch (action) {
            case "ouvrir":
                return ouvrir(interaction, client);

            case "prendre":
                return prendre(interaction, client);

            case "fermer":
                return demanderFermeture(interaction);

            case "fermer-confirmer":
                return confirmerFermeture(interaction, client);

            case "fermer-annuler":
                return interaction.update({ content: t("tickets.fermetureAnnulee", {}, L), components: [] });

            default:
                return undefined;
        }
    },
};