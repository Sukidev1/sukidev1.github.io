// sukitickets/src/composants/setup.js

/* ===================================================
   Boutons, menus et fenêtres du panneau /setup
   Tous leurs identifiants commencent par "setup:"

   Écran principal
     setup:roles       → choix des rôles staff
     setup:categorie   → choix de la catégorie des tickets
     setup:logs        → choix du salon de logs
     setup:auto        → création automatique des salons
     setup:categories  → ouvre l'écran des catégories
     setup:langue      → changement de langue
     setup:actualiser  → recharge le récapitulatif

   Écran des catégories
     setup:cat-choisir              → sélection d'une catégorie
     setup:cat-ajouter              → ouvre la fenêtre d'ajout
     setup:cat-modifier:<id>        → ouvre la fenêtre de modification
     setup:cat-supprimer:<id>       → supprime la catégorie
     setup:cat-fenetre-ajout        → fenêtre d'ajout validée
     setup:cat-fenetre-modif:<id>   → fenêtre de modification validée
     setup:retour                   → retour à l'écran principal
   =================================================== */

const { ChannelType, PermissionFlagsBits, MessageFlags } = require("discord.js");

const { t, languesDisponibles } = require("../utils/langue");
const { lireServeur, modifierServeur } = require("../utils/donnees");
const { etatServeur } = require("../utils/verifierConfig");
const { lireEmoji } = require("../utils/emoji");
const { construirePanneau } = require("../setup/panneau");
const {
    construireEcranCategories,
    construireFenetreCategorie,
    nouvelIdentifiant,
    MAX_CATEGORIES,
} = require("../setup/categories");
const { rafraichirPanneaux } = require("../tickets/panneauTickets");

/** Petit raccourci pour répondre en privé */
const prive = (content) => ({ content, flags: MessageFlags.Ephemeral });

/* ---------- Création automatique de la catégorie et du salon de logs ---------- */

async function creerAutomatiquement(interaction, client) {
    const serveur = interaction.guild;
    const reglages = lireServeur(serveur.id);
    const L = reglages.langue;
    const etat = etatServeur(serveur, reglages);

    // Il faut connaître les rôles staff pour leur donner accès
    if (etat.roles.length === 0) {
        return interaction.reply(prive(t("setup.autoRolesDabord", {}, L)));
    }

    // Création possiblement un peu longue : on prévient Discord qu'on travaille
    await interaction.deferUpdate();

    // Permissions : invisible pour tout le monde, sauf le staff et le bot
    const permissions = [
        { id: serveur.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
        {
            id: client.user.id,
            allow: [
                PermissionFlagsBits.ViewChannel,
                PermissionFlagsBits.ManageChannels,
                PermissionFlagsBits.SendMessages,
                PermissionFlagsBits.EmbedLinks,
                PermissionFlagsBits.AttachFiles,
                PermissionFlagsBits.ReadMessageHistory,
            ],
        },
        ...etat.roles.map((id) => ({
            id,
            allow: [
                PermissionFlagsBits.ViewChannel,
                PermissionFlagsBits.SendMessages,
                PermissionFlagsBits.ReadMessageHistory,
                PermissionFlagsBits.AttachFiles,
            ],
        })),
    ];

    const crees = [];

    try {
        let idCategorie = etat.etatCategorie === "ok" ? reglages.categorieTickets : null;

        if (!idCategorie) {
            const categorie = await serveur.channels.create({
                name: t("setup.nomCategorieAuto", {}, L),
                type: ChannelType.GuildCategory,
                permissionOverwrites: permissions,
            });
            idCategorie = categorie.id;
            crees.push(`**${categorie.name}**`);
        }

        let idLogs = etat.etatLogs === "ok" ? reglages.salonLogs : null;

        if (!idLogs) {
            const logs = await serveur.channels.create({
                name: t("setup.nomLogsAuto", {}, L),
                type: ChannelType.GuildText,
                parent: idCategorie,
                permissionOverwrites: permissions,
            });
            idLogs = logs.id;
            crees.push(`<#${logs.id}>`);
        }

        modifierServeur(serveur.id, { categorieTickets: idCategorie, salonLogs: idLogs });
    } catch (erreur) {
        console.error(erreur);
        await interaction.editReply(construirePanneau(serveur, client));
        return interaction.followUp(prive(t("setup.autoErreur", {}, L)));
    }

    await interaction.editReply(construirePanneau(serveur, client));

    const message = crees.length > 0
        ? t("setup.autoFait", { elements: crees.join(", ") }, L)
        : t("setup.autoRien", {}, L);

    return interaction.followUp(prive(message));
}

/* ---------- Ajout ou modification d'une catégorie (fenêtre validée) ---------- */

async function enregistrerCategorie(interaction, client, idModifiee) {
    const serveur = interaction.guild;
    const reglages = lireServeur(serveur.id);
    const L = reglages.langue;
    const categories = [...reglages.categories];

    const nom = interaction.fields.getTextInputValue("nom").trim();
    const texteEmoji = interaction.fields.getTextInputValue("emoji");
    const description = interaction.fields.getTextInputValue("description").trim() || null;

    // Emoji invalide : on enregistre quand même, sans emoji, et on prévient
    const { valide, emoji } = lireEmoji(texteEmoji);
    const avertissements = [];
    if (!valide) avertissements.push(t("categories.emojiInvalide", { emoji: texteEmoji.trim() }, L));

    let selection;

    if (idModifiee) {
        const index = categories.findIndex((c) => c.id === idModifiee);
        if (index === -1) return interaction.reply(prive(t("categories.introuvable", {}, L)));

        categories[index] = { ...categories[index], nom, emoji, description };
        selection = idModifiee;
        avertissements.unshift(t("categories.modifiee", { nom }, L));
    } else {
        if (categories.length >= MAX_CATEGORIES) return interaction.reply(prive(t("categories.limite", {}, L)));

        selection = nouvelIdentifiant(nom, categories);
        categories.push({ id: selection, emoji, nom, description });
        avertissements.unshift(t("categories.ajoutee", { nom }, L));
    }

    modifierServeur(serveur.id, { categories });
    await interaction.update(construireEcranCategories(serveur, client, selection));

    // Les menus déjà envoyés avec /panel sont mis à jour
    const nombre = await rafraichirPanneaux(serveur, client);
    if (nombre > 0) avertissements.push(t("categories.panneauxMisAJour", { nombre }, L));

    return interaction.followUp(prive(avertissements.join("\n")));
}

/* ---------- Aiguillage selon le bouton, menu ou fenêtre utilisé ---------- */

module.exports = {
    prefixe: "setup",

    async execute(interaction, client) {
        const serveur = interaction.guild;
        const reglages = lireServeur(serveur.id);
        const L = reglages.langue;
        const [, action, argument] = interaction.customId.split(":");

        // Sécurité : seuls les administrateurs peuvent modifier
        if (!interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)) {
            return interaction.reply(prive(t("setup.reserveAdmin", {}, L)));
        }

        let avertissement = null;

        switch (action) {
            /* ===== Écran principal ===== */

            case "roles": {
                // On écarte @everyone et les rôles gérés par des bots
                const valides = interaction.values.filter((id) => {
                    const role = serveur.roles.cache.get(id);
                    return id !== serveur.id && role && !role.managed;
                });
                if (valides.length < interaction.values.length) avertissement = t("setup.roleInvalide", {}, L);
                modifierServeur(serveur.id, { rolesStaff: valides });
                break;
            }

            case "categorie":
                modifierServeur(serveur.id, { categorieTickets: interaction.values[0] ?? null });
                break;

            case "logs":
                modifierServeur(serveur.id, { salonLogs: interaction.values[0] ?? null });
                break;

            case "langue": {
                // Passe à la langue suivante (en → fr → en…), puis met à jour les menus déjà envoyés
                const langues = languesDisponibles();
                const suivante = langues[(langues.indexOf(L) + 1) % langues.length];
                modifierServeur(serveur.id, { langue: suivante });
                await interaction.update(construirePanneau(serveur, client));
                await rafraichirPanneaux(serveur, client);
                return;
            }

            case "auto":
                return creerAutomatiquement(interaction, client);

            case "categories":
            case "cat-choisir":
                // Écran des catégories (avec la catégorie choisie dans le menu, s'il y en a une)
                return interaction.update(construireEcranCategories(serveur, client, interaction.values?.[0] ?? null));

            /* ===== Écran des catégories ===== */

            case "cat-ajouter":
                return interaction.showModal(construireFenetreCategorie(L));

            case "cat-modifier": {
                const categorie = reglages.categories.find((c) => c.id === argument);
                if (!categorie) return interaction.reply(prive(t("categories.introuvable", {}, L)));
                return interaction.showModal(construireFenetreCategorie(L, categorie));
            }

            case "cat-supprimer": {
                const categorie = reglages.categories.find((c) => c.id === argument);
                if (!categorie) return interaction.reply(prive(t("categories.introuvable", {}, L)));
                if (reglages.categories.length <= 1) return interaction.reply(prive(t("categories.derniere", {}, L)));

                modifierServeur(serveur.id, { categories: reglages.categories.filter((c) => c.id !== argument) });
                await interaction.update(construireEcranCategories(serveur, client));

                const messages = [t("categories.supprimee", { nom: categorie.nom }, L)];
                const nombre = await rafraichirPanneaux(serveur, client);
                if (nombre > 0) messages.push(t("categories.panneauxMisAJour", { nombre }, L));
                return interaction.followUp(prive(messages.join("\n")));
            }

            case "cat-fenetre-ajout":
                return enregistrerCategorie(interaction, client, null);

            case "cat-fenetre-modif":
                return enregistrerCategorie(interaction, client, argument);

            case "retour":
            case "actualiser":
            default:
                break;
        }

        // On met à jour le panneau principal avec les nouveaux réglages
        await interaction.update(construirePanneau(serveur, client));

        if (avertissement) await interaction.followUp(prive(avertissement));
    },
};