// sukitickets/src/handlers/componentHandler.js

/* ===================================================
   Chargement des gestionnaires de boutons et menus
   Lit tous les fichiers .js de src/composants
   (et de src/premium/composants si la version
   premium est installée).

   Chaque fichier gère un "préfixe" : par exemple,
   composants/setup.js reçoit tous les boutons et
   menus dont l'identifiant commence par "setup:".
   =================================================== */

const fs = require("node:fs");
const path = require("node:path");
const { Collection } = require("discord.js");
const { t } = require("../utils/langue");

const DOSSIER_COMPOSANTS = path.join(__dirname, "..", "composants");
const DOSSIER_COMPOSANTS_PREMIUM = path.join(__dirname, "..", "premium", "composants");

/**
 * Chaque fichier doit exporter :
 *   { prefixe: "setup", execute(interaction, client) }
 */
function chargerComposants(client) {
    client.composants = new Collection();

    const dossiers = [DOSSIER_COMPOSANTS];
    if (fs.existsSync(DOSSIER_COMPOSANTS_PREMIUM)) dossiers.push(DOSSIER_COMPOSANTS_PREMIUM);

    for (const dossier of dossiers) {
        if (!fs.existsSync(dossier)) continue;

        for (const nom of fs.readdirSync(dossier)) {
            if (!nom.endsWith(".js")) continue;

            const composant = require(path.join(dossier, nom));

            if (!composant.prefixe || !composant.execute) {
                console.warn(t("console.composantIgnore", { fichier: nom }));
                continue;
            }

            client.composants.set(composant.prefixe, composant);
        }
    }

    console.log(t("console.composantsCharges", { nombre: client.composants.size }));
}

module.exports = { chargerComposants };