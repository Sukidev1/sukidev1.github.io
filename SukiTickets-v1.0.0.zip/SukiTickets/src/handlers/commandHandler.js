// sukitickets/src/handlers/commandHandler.js

/* ===================================================
   Chargement des commandes
   Lit tous les fichiers .js de src/commands
   (et de src/premium/commands si la version premium
   est installée).
   =================================================== */

const fs = require("node:fs");
const path = require("node:path");
const { t } = require("../utils/langue");

const DOSSIER_COMMANDES = path.join(__dirname, "..", "commands");
const DOSSIER_COMMANDES_PREMIUM = path.join(__dirname, "..", "premium", "commands");

/**
 * Renvoie le chemin de tous les fichiers de commandes à charger.
 * Utilisé à la fois par le bot et par deploy-commands.js.
 */
function listerFichiersCommandes() {
    const dossiers = [DOSSIER_COMMANDES];

    if (fs.existsSync(DOSSIER_COMMANDES_PREMIUM)) {
        dossiers.push(DOSSIER_COMMANDES_PREMIUM);
    }

    const fichiers = [];

    for (const dossier of dossiers) {
        if (!fs.existsSync(dossier)) continue;

        for (const nom of fs.readdirSync(dossier)) {
            if (nom.endsWith(".js")) {
                fichiers.push(path.join(dossier, nom));
            }
        }
    }

    return fichiers;
}

/**
 * Charge les commandes dans client.commands.
 * Chaque fichier doit exporter { data, execute }.
 */
function chargerCommandes(client) {
    for (const fichier of listerFichiersCommandes()) {
        const commande = require(fichier);

        if (!commande.data || !commande.execute) {
            console.warn(t("console.commandeIgnoree", { fichier: path.basename(fichier) }));
            continue;
        }

        client.commands.set(commande.data.name, commande);
    }

    console.log(t("console.commandesChargees", { nombre: client.commands.size }));
}

module.exports = { chargerCommandes, listerFichiersCommandes };