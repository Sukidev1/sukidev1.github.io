// sukitickets/src/handlers/eventHandler.js

/* ===================================================
   Chargement des événements
   Lit tous les fichiers .js de src/events
   (et de src/premium/events si la version premium
   est installée) et les branche sur le client.
   =================================================== */

const fs = require("node:fs");
const path = require("node:path");
const { t } = require("../utils/langue");

const DOSSIER_EVENEMENTS = path.join(__dirname, "..", "events");
const DOSSIER_EVENEMENTS_PREMIUM = path.join(__dirname, "..", "premium", "events");

/**
 * Chaque fichier doit exporter :
 *   { name: "nomDeLÉvénement", once: true|false, execute(...args, client) }
 */
function chargerEvenements(client) {
    const dossiers = [DOSSIER_EVENEMENTS];

    if (fs.existsSync(DOSSIER_EVENEMENTS_PREMIUM)) {
        dossiers.push(DOSSIER_EVENEMENTS_PREMIUM);
    }

    let total = 0;

    for (const dossier of dossiers) {
        if (!fs.existsSync(dossier)) continue;

        for (const nom of fs.readdirSync(dossier)) {
            if (!nom.endsWith(".js")) continue;

            const evenement = require(path.join(dossier, nom));

            if (!evenement.name || !evenement.execute) {
                console.warn(t("console.evenementIgnore", { fichier: nom }));
                continue;
            }

            // On passe toujours le client en dernier argument
            const lancer = (...args) => evenement.execute(...args, client);

            if (evenement.once) {
                client.once(evenement.name, lancer);
            } else {
                client.on(evenement.name, lancer);
            }

            total++;
        }
    }

    console.log(t("console.evenementsCharges", { nombre: total }));
}

module.exports = { chargerEvenements };