// sukitickets/src/premium/events/inactivite.js

/* ===================================================
   Fermeture automatique des tickets inactifs
   Démarre quand le bot est connecté, puis vérifie
   régulièrement chaque ticket ouvert :
   1) aucun message depuis X heures → le bot prévient
      dans le ticket (en mentionnant l'auteur)
   2) toujours aucun message Y minutes après
      l'avertissement → le ticket est fermé, avec
      transcription et logs comme d'habitude
   Si quelqu'un écrit après l'avertissement, tout
   repart à zéro.
   =================================================== */

const { Events, EmbedBuilder, SnowflakeUtil } = require("discord.js");

const { t } = require("../../utils/langue");
const { lireServeur, lireTickets, ecrireTickets } = require("../../utils/donnees");
const { formaterDuree } = require("../../utils/duree");
const { fermerTicket, estEnFermeture } = require("../../tickets/fermeture");
const { premiumDe, configPremium } = require("../outils");

/** Date du dernier message d'un salon (ou d'ouverture du ticket si aucun) */
function dernierMessage(salon, ticket) {
    return salon.lastMessageId ? Number(SnowflakeUtil.timestampFrom(salon.lastMessageId)) : ticket.ouvertLe;
}

async function verifierServeur(serveur, client) {
    const reglages = lireServeur(serveur.id);
    const { inactiviteHeures, avertissementMinutes } = premiumDe(reglages).parametres;
    if (!inactiviteHeures) return; // désactivée sur ce serveur

    const L = reglages.langue;
    const maintenant = Date.now();
    const tickets = lireTickets(serveur.id);
    let modifie = false;

    for (const [idSalon, ticket] of Object.entries(tickets.ouverts)) {
        const salon = serveur.channels.cache.get(idSalon);
        if (!salon || estEnFermeture(idSalon)) continue;

        // Un avertissement a déjà été envoyé
        if (ticket.avertissement) {
            if (salon.lastMessageId === ticket.avertissement) {
                // Personne n'a répondu : on ferme une fois le délai écoulé
                if (maintenant - ticket.avertiLe >= avertissementMinutes * 60000) {
                    await fermerTicket(salon, null, client);
                }
            } else {
                // Quelqu'un a écrit depuis : on oublie l'avertissement
                delete ticket.avertissement;
                delete ticket.avertiLe;
                modifie = true;
            }
            continue;
        }

        // Pas encore d'avertissement : le ticket est-il inactif ?
        const inactifDepuis = maintenant - dernierMessage(salon, ticket);
        if (inactifDepuis < inactiviteHeures * 3600000) continue;

        const message = await salon.send({
            content: `<@${ticket.auteur}>`,
            embeds: [
                new EmbedBuilder()
                    .setColor(client.config.couleurs.erreur)
                    .setTitle(t("premium.inactivite.titre", {}, L))
                    .setDescription(t("premium.inactivite.texte", {
                        membre: `<@${ticket.auteur}>`,
                        duree: formaterDuree(inactifDepuis, L),
                        minutes: avertissementMinutes,
                    }, L)),
            ],
            allowedMentions: { users: [ticket.auteur] },
        }).catch(() => null);

        if (message) {
            ticket.avertissement = message.id;
            ticket.avertiLe = maintenant;
            modifie = true;
        }
    }

    // On relit avant d'enregistrer : un ticket a pu être fermé pendant la vérification
    if (modifie) {
        const aJour = lireTickets(serveur.id);
        for (const [idSalon, ticket] of Object.entries(tickets.ouverts)) {
            if (aJour.ouverts[idSalon]) {
                aJour.ouverts[idSalon].avertissement = ticket.avertissement;
                aJour.ouverts[idSalon].avertiLe = ticket.avertiLe;
            }
        }
        ecrireTickets(serveur.id, aJour);
    }
}

module.exports = {
    name: Events.ClientReady,
    once: true,

    execute(client) {
        const minutes = configPremium.verificationMinutes;
        console.log(t("premium.console.inactiviteDemarree", { minutes }));

        const verifier = async () => {
            for (const serveur of client.guilds.cache.values()) {
                await verifierServeur(serveur, client).catch((erreur) => console.error(erreur));
            }
        };

        setTimeout(verifier, 60000);              // une première fois 1 minute après le démarrage
        setInterval(verifier, minutes * 60000);   // puis régulièrement
    },

    // Exporté pour les tests
    verifierServeur,
};