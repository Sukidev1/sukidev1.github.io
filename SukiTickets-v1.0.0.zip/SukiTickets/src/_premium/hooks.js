// sukitickets/src/premium/hooks.js

/* ===================================================
   Branchements premium (appelés par la version
   gratuite grâce à src/tickets/hooks.js)

   avantOuverture → si la catégorie a un formulaire,
                    affiche la fenêtre de questions.
                    La suite se passe dans
                    composants/premium.js (premium:reponses).
   fermeture      → envoie la demande de note ⭐
                    en message privé à l'auteur.
   =================================================== */

const {
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle,
    ActionRowBuilder,
    ButtonBuilder,
    ButtonStyle,
    EmbedBuilder,
} = require("discord.js");

const { t } = require("../utils/langue");
const { piedDePage } = require("../utils/marque");
const { premiumDe } = require("./outils");

module.exports = {
    /* ---------- Formulaire avant l'ouverture ---------- */

    async avantOuverture({ interaction, categorie, reglages }) {
        const questions = premiumDe(reglages).formulaires[categorie.id];
        if (!questions?.length) return false; // pas de formulaire : ouverture normale

        const fenetre = new ModalBuilder()
            .setCustomId(`premium:reponses:${categorie.id}`)
            .setTitle(`${categorie.emoji ?? "🎫"} ${categorie.nom}`.slice(0, 45));

        questions.forEach((question, i) => {
            fenetre.addComponents(new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                    .setCustomId(`q${i}`)
                    .setLabel(question.slice(0, 45))
                    .setStyle(TextInputStyle.Paragraph)
                    .setMaxLength(800)
                    .setRequired(true),
            ));
        });

        await interaction.showModal(fenetre);
        return true; // c'est le premium qui s'occupe de la suite
    },

    /* ---------- Demande de note après la fermeture ---------- */

    async fermeture({ client, salon, ticket, reglages }) {
        if (!premiumDe(reglages).parametres.notes) return;

        const auteur = await client.users.fetch(ticket.auteur).catch(() => null);
        if (!auteur) return;

        const L = reglages.langue;
        const numero = String(ticket.numero).padStart(4, "0");

        const boutons = new ActionRowBuilder().addComponents(
            [1, 2, 3, 4, 5].map((note) => new ButtonBuilder()
                .setCustomId(`premium:note:${salon.guild.id}:${ticket.numero}:${note}`)
                .setLabel(String(note))
                .setEmoji("⭐")
                .setStyle(note >= 4 ? ButtonStyle.Success : ButtonStyle.Secondary)),
        );

        await auteur.send({
            embeds: [
                new EmbedBuilder()
                    .setColor(client.config.couleurs.principale)
                    .setTitle(t("premium.notes.titre", { numero }, L))
                    .setDescription(t("premium.notes.description", { serveur: salon.guild.name }, L))
                    .setFooter({ text: piedDePage(client, L) }),
            ],
            components: [boutons],
        }).catch(() => {}); // MP fermés : tant pis
    },
};