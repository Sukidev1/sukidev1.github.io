// sukitickets/src/premium/composants/premium.js

/* ===================================================
   Boutons et fenêtres de la version premium
   Identifiants qui commencent par "premium:"
     premium:reponses:<catégorie>   → le membre a rempli le formulaire
                                      → création du ticket
     premium:questions:<catégorie>  → un admin a modifié les questions
                                      d'un formulaire (/formulaire)
     premium:note:<serveur>:<numéro>:<note> → note ⭐ envoyée en MP
   =================================================== */

const { MessageFlags, EmbedBuilder } = require("discord.js");

const { t } = require("../../utils/langue");
const { lireServeur, lireTickets, ecrireTickets } = require("../../utils/donnees");
const { etatServeur } = require("../../utils/verifierConfig");
const { piedDePage } = require("../../utils/marque");
const { creerTicket, ticketsOuvertsDe } = require("../../tickets/creation");
const { envoyerLog } = require("../../tickets/logs");
const { premiumDe, modifierPremium } = require("../outils");

const prive = (content) => ({ content, flags: MessageFlags.Ephemeral });

/* ---------- Formulaire rempli → création du ticket ---------- */

async function reponses(interaction, client, idCategorie) {
    const serveur = interaction.guild;
    const reglages = lireServeur(serveur.id);
    const L = reglages.langue;

    // On remet le menu des tickets à zéro, puis on vérifie que tout est encore bon
    await interaction.update({ components: interaction.message.components });

    if (!etatServeur(serveur, reglages).pret) return interaction.followUp(prive(t("tickets.indisponible", {}, L)));

    const categorie = reglages.categories.find((c) => c.id === idCategorie);
    if (!categorie) return interaction.followUp(prive(t("panel.categorieIntrouvable", {}, L)));

    const ouverts = ticketsOuvertsDe(serveur, interaction.user.id);
    if (ouverts.length >= client.config.tickets.maxParMembre) {
        return interaction.followUp(prive(t("tickets.dejaOuvert", {
            nombre: ouverts.length,
            salons: ouverts.map((id) => `<#${id}>`).join(", "),
        }, L)));
    }

    const questions = premiumDe(reglages).formulaires[idCategorie] ?? [];
    const lesReponses = questions.map((question, i) => ({
        question: question.slice(0, 256),
        reponse: interaction.fields.getTextInputValue(`q${i}`)?.trim() ?? "",
    }));

    return creerTicket(interaction, client, categorie, lesReponses);
}

/* ---------- Questions d'un formulaire modifiées (/formulaire) ---------- */

async function questions(interaction, idCategorie) {
    const reglages = lireServeur(interaction.guildId);
    const L = reglages.langue;
    const categorie = reglages.categories.find((c) => c.id === idCategorie);

    if (!categorie) return interaction.reply(prive(t("premium.formulaire.categorieIntrouvable", {}, L)));

    const liste = [0, 1, 2, 3, 4]
        .map((i) => interaction.fields.getTextInputValue(`q${i}`)?.trim())
        .filter(Boolean);

    modifierPremium(interaction.guildId, (premium) => {
        if (liste.length > 0) premium.formulaires[idCategorie] = liste;
        else delete premium.formulaires[idCategorie];
    });

    const nomCategorie = `${categorie.emoji ?? "🎫"} ${categorie.nom}`;

    if (liste.length === 0) {
        return interaction.reply(prive(t("premium.formulaire.supprime", { categorie: nomCategorie }, L)));
    }

    return interaction.reply(prive(t("premium.formulaire.enregistre", {
        categorie: nomCategorie,
        nombre: liste.length,
        questions: liste.map((q, i) => `**${i + 1}.** ${q}`).join("\n"),
    }, L)));
}

/* ---------- Note ⭐ (bouton dans un message privé) ---------- */

async function noter(interaction, client, idServeur, numero, note) {
    const reglages = lireServeur(idServeur);
    const L = reglages.langue;
    const tickets = lireTickets(idServeur);
    const ticket = (tickets.historique ?? []).find((h) => h.numero === numero);

    if (!ticket || ticket.auteur !== interaction.user.id) {
        return interaction.update({ content: t("premium.notes.introuvable", {}, L), embeds: [], components: [] });
    }
    if (ticket.note) {
        return interaction.update({ content: t("premium.notes.dejaNote", {}, L), components: [] });
    }

    ticket.note = note;
    ticket.noteLe = Date.now();
    ecrireTickets(idServeur, tickets);

    await interaction.update({
        embeds: [
            new EmbedBuilder()
                .setColor(client.config.couleurs.succes)
                .setDescription(t("premium.notes.merci", { note }, L))
                .setFooter({ text: piedDePage(client, L) }),
        ],
        components: [],
    });

    // Note visible dans les logs du serveur
    const serveur = client.guilds.cache.get(idServeur);
    if (serveur) {
        await envoyerLog(serveur, client, {
            titre: t("premium.notes.logTitre", {}, L),
            couleur: client.config.couleurs.succes,
            champs: [
                { name: t("logs.champTicket", {}, L), value: `#${String(numero).padStart(4, "0")}` },
                { name: t("premium.notes.champNote", {}, L), value: `${"⭐".repeat(note)} (${note}/5)` },
                { name: t("logs.champAuteur", {}, L), value: `<@${ticket.auteur}>` },
                { name: t("logs.champPrisEnCharge", {}, L), value: ticket.prisEnCharge ? `<@${ticket.prisEnCharge}>` : t("logs.personne", {}, L) },
            ],
        });
    }
}

/* ---------- Aiguillage ---------- */

module.exports = {
    prefixe: "premium",

    async execute(interaction, client) {
        const [, action, ...morceaux] = interaction.customId.split(":");

        switch (action) {
            case "reponses":
                return reponses(interaction, client, morceaux[0]);

            case "questions":
                return questions(interaction, morceaux[0]);

            case "note":
                return noter(interaction, client, morceaux[0], Number(morceaux[1]), Number(morceaux[2]));

            default:
                return undefined;
        }
    },
};