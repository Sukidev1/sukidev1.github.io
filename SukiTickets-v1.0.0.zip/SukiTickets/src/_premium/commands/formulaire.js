// sukitickets/src/premium/commands/formulaire.js

/* ===================================================
   /formulaire categorie — choisir les questions
   (jusqu'à 5) posées au membre avant l'ouverture
   d'un ticket de cette catégorie.
   Laisser toutes les questions vides supprime
   le formulaire. Réservé aux administrateurs.
   =================================================== */

const {
    SlashCommandBuilder,
    PermissionFlagsBits,
    InteractionContextType,
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle,
    ActionRowBuilder,
    MessageFlags,
} = require("discord.js");

const { t, localisations } = require("../../utils/langue");
const { lireServeur } = require("../../utils/donnees");
const { premiumDe } = require("../outils");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("formulaire")
        .setNameLocalizations({ "en-US": "form", "en-GB": "form" })
        .setDescription(t("premium.commandes.formulaire.description", {}, "en"))
        .setDescriptionLocalizations(localisations("premium.commandes.formulaire.description"))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
        .setContexts(InteractionContextType.Guild)
        .addStringOption((option) => option
            .setName("categorie")
            .setNameLocalizations({ "en-US": "category", "en-GB": "category" })
            .setDescription(t("premium.commandes.formulaire.optionCategorie", {}, "en"))
            .setDescriptionLocalizations(localisations("premium.commandes.formulaire.optionCategorie"))
            .setAutocomplete(true)
            .setRequired(true)),

    /* Suggestions pendant la saisie : les catégories du serveur */
    async autocomplete(interaction) {
        const recherche = interaction.options.getFocused().toLowerCase();
        const { categories } = lireServeur(interaction.guildId);

        await interaction.respond(categories
            .filter((c) => c.nom.toLowerCase().includes(recherche))
            .slice(0, 25)
            .map((c) => ({ name: `${c.emoji ?? "🎫"} ${c.nom}`.slice(0, 100), value: c.id })));
    },

    async execute(interaction) {
        const reglages = lireServeur(interaction.guildId);
        const L = reglages.langue;
        const categorie = reglages.categories.find((c) => c.id === interaction.options.getString("categorie"));

        if (!categorie) {
            return interaction.reply({ content: t("premium.formulaire.categorieIntrouvable", {}, L), flags: MessageFlags.Ephemeral });
        }

        const actuelles = premiumDe(reglages).formulaires[categorie.id] ?? [];

        const fenetre = new ModalBuilder()
            .setCustomId(`premium:questions:${categorie.id}`)
            .setTitle(t("premium.formulaire.titreFenetre", { categorie: categorie.nom }, L).slice(0, 45));

        for (let i = 0; i < 5; i++) {
            const champ = new TextInputBuilder()
                .setCustomId(`q${i}`)
                .setLabel(t("premium.formulaire.champQuestion", { numero: i + 1 }, L).slice(0, 45))
                .setPlaceholder(t("premium.formulaire.exempleQuestion", {}, L).slice(0, 100))
                .setStyle(TextInputStyle.Short)
                .setMaxLength(45) // limite de Discord pour le titre d'une question
                .setRequired(false);

            if (actuelles[i]) champ.setValue(actuelles[i]);

            fenetre.addComponents(new ActionRowBuilder().addComponents(champ));
        }

        return interaction.showModal(fenetre);
    },
};