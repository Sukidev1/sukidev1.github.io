// sukitickets/src/premium/commands/stats.js

/* ===================================================
   /stats periode — statistiques des tickets
   (réservé au staff) : tickets ouverts et fermés,
   temps moyen de prise en charge, durée moyenne,
   note moyenne et classement de l'équipe.
   =================================================== */

const { SlashCommandBuilder, InteractionContextType, MessageFlags, EmbedBuilder } = require("discord.js");

const { t, localisations } = require("../../utils/langue");
const { lireServeur, lireTickets } = require("../../utils/donnees");
const { estStaff } = require("../../utils/staff");
const { formaterDuree } = require("../../utils/duree");
const { piedDePage } = require("../../utils/marque");

const PERIODES = { "7": 7, "30": 30, tout: null };
const CLE_PERIODE = { "7": "jours7", "30": "jours30", tout: "tout" };
const MEDAILLES = ["🥇", "🥈", "🥉"];

const moyenne = (valeurs) => (valeurs.length ? valeurs.reduce((a, b) => a + b, 0) / valeurs.length : null);
const arrondi = (nombre) => Math.round(nombre * 10) / 10;

module.exports = {
    data: new SlashCommandBuilder()
        .setName("stats")
        .setDescription(t("premium.commandes.stats.description", {}, "en"))
        .setDescriptionLocalizations(localisations("premium.commandes.stats.description"))
        .setContexts(InteractionContextType.Guild)
        .addStringOption((option) => option
            .setName("periode")
            .setNameLocalizations({ "en-US": "period", "en-GB": "period" })
            .setDescription(t("premium.commandes.stats.optionPeriode", {}, "en"))
            .setDescriptionLocalizations(localisations("premium.commandes.stats.optionPeriode"))
            .setRequired(false)
            .addChoices(...Object.keys(PERIODES).map((valeur) => ({
                name: t(`premium.commandes.stats.${CLE_PERIODE[valeur]}`, {}, "en"),
                name_localizations: localisations(`premium.commandes.stats.${CLE_PERIODE[valeur]}`),
                value: valeur,
            })))),

    async execute(interaction, client) {
        const reglages = lireServeur(interaction.guildId);
        const L = reglages.langue;

        if (!estStaff(interaction.member, reglages)) {
            return interaction.reply({ content: t("gestion.reserveStaff", {}, L), flags: MessageFlags.Ephemeral });
        }

        const choix = interaction.options.getString("periode") ?? "30";
        const jours = PERIODES[choix];
        const depuis = jours ? Date.now() - jours * 86400000 : 0;

        const tickets = lireTickets(interaction.guildId);
        const historique = tickets.historique ?? [];
        const ouverts = Object.values(tickets.ouverts);

        // Tickets de la période
        const fermes = historique.filter((h) => h.fermeLe >= depuis);
        const ouvertsPeriode = [...historique, ...ouverts].filter((x) => x.ouvertLe >= depuis);

        const priseEnCharge = moyenne(ouvertsPeriode.filter((x) => x.prisEnChargeLe).map((x) => x.prisEnChargeLe - x.ouvertLe));
        const duree = moyenne(fermes.map((h) => h.fermeLe - h.ouvertLe));
        const notes = fermes.filter((h) => h.note).map((h) => h.note);
        const noteMoyenne = moyenne(notes);

        // Classement du staff (tickets fermés qu'il avait pris en charge)
        const parStaff = new Map();
        for (const h of fermes.filter((x) => x.prisEnCharge)) {
            const ligne = parStaff.get(h.prisEnCharge) ?? { nombre: 0, notes: [] };
            ligne.nombre += 1;
            if (h.note) ligne.notes.push(h.note);
            parStaff.set(h.prisEnCharge, ligne);
        }

        const classement = [...parStaff.entries()]
            .sort((a, b) => b[1].nombre - a[1].nombre)
            .slice(0, 10)
            .map(([id, { nombre, notes: n }], i) => t("premium.stats.ligneClassement", {
                medaille: MEDAILLES[i] ?? `**${i + 1}.**`,
                staff: `<@${id}>`,
                nombre,
                note: n.length ? t("premium.stats.notePourStaff", { note: arrondi(moyenne(n)) }, L) : "",
            }, L));

        const indisponible = t("premium.stats.nonDisponible", {}, L);

        const embed = new EmbedBuilder()
            .setColor(client.config.couleurs.principale)
            .setTitle(t("premium.stats.titre", { periode: t(`premium.commandes.stats.${CLE_PERIODE[choix]}`, {}, L) }, L))
            .addFields(
                { name: t("premium.stats.ouverts", {}, L), value: String(ouvertsPeriode.length), inline: true },
                { name: t("premium.stats.fermes", {}, L), value: String(fermes.length), inline: true },
                { name: t("premium.stats.enCours", {}, L), value: String(ouverts.length), inline: true },
                { name: t("premium.stats.priseEnCharge", {}, L), value: priseEnCharge !== null ? formaterDuree(priseEnCharge, L) : indisponible, inline: true },
                { name: t("premium.stats.duree", {}, L), value: duree !== null ? formaterDuree(duree, L) : indisponible, inline: true },
                {
                    name: t("premium.stats.note", {}, L),
                    value: noteMoyenne !== null
                        ? t("premium.stats.nombreNotes", { note: arrondi(noteMoyenne), nombre: notes.length }, L)
                        : t("premium.stats.aucuneNote", {}, L),
                    inline: true,
                },
                { name: t("premium.stats.classement", {}, L), value: classement.join("\n") || t("premium.stats.aucunClassement", {}, L) },
            )
            .setFooter({ text: piedDePage(client, L) })
            .setTimestamp();

        return interaction.reply({ embeds: [embed], allowedMentions: { parse: [] } });
    },
};