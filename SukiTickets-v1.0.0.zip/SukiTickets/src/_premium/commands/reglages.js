// sukitickets/src/premium/commands/reglages.js

/* ===================================================
   /premium-reglages — réglages de la version premium
   (réservé aux administrateurs). Options :
     inactivite     → heures sans message avant la
                      fermeture automatique (0 = désactivée)
     avertissement  → minutes entre l'avertissement
                      et la fermeture
     notes          → demander une note ⭐ après chaque ticket
   Sans option : affiche simplement les réglages actuels.
   =================================================== */

const {
    SlashCommandBuilder,
    PermissionFlagsBits,
    InteractionContextType,
    MessageFlags,
    EmbedBuilder,
} = require("discord.js");

const { t, localisations } = require("../../utils/langue");
const { lireServeur } = require("../../utils/donnees");
const { piedDePage } = require("../../utils/marque");
const { modifierPremium } = require("../outils");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("premium-reglages")
        .setNameLocalizations({ "en-US": "premium-settings", "en-GB": "premium-settings" })
        .setDescription(t("premium.commandes.reglages.description", {}, "en"))
        .setDescriptionLocalizations(localisations("premium.commandes.reglages.description"))
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
        .setContexts(InteractionContextType.Guild)
        .addIntegerOption((option) => option
            .setName("inactivite")
            .setNameLocalizations({ "en-US": "inactivity", "en-GB": "inactivity" })
            .setDescription(t("premium.commandes.reglages.optionInactivite", {}, "en"))
            .setDescriptionLocalizations(localisations("premium.commandes.reglages.optionInactivite"))
            .setMinValue(0)
            .setMaxValue(720)
            .setRequired(false))
        .addIntegerOption((option) => option
            .setName("avertissement")
            .setNameLocalizations({ "en-US": "warning", "en-GB": "warning" })
            .setDescription(t("premium.commandes.reglages.optionAvertissement", {}, "en"))
            .setDescriptionLocalizations(localisations("premium.commandes.reglages.optionAvertissement"))
            .setMinValue(5)
            .setMaxValue(1440)
            .setRequired(false))
        .addBooleanOption((option) => option
            .setName("notes")
            .setNameLocalizations({ "en-US": "ratings", "en-GB": "ratings" })
            .setDescription(t("premium.commandes.reglages.optionNotes", {}, "en"))
            .setDescriptionLocalizations(localisations("premium.commandes.reglages.optionNotes"))
            .setRequired(false)),

    async execute(interaction, client) {
        const L = lireServeur(interaction.guildId).langue;

        const inactivite = interaction.options.getInteger("inactivite");
        const avertissement = interaction.options.getInteger("avertissement");
        const notes = interaction.options.getBoolean("notes");

        // Enregistre uniquement ce qui a été donné
        const { parametres } = modifierPremium(interaction.guildId, (premium) => {
            if (inactivite !== null) premium.parametres.inactiviteHeures = inactivite;
            if (avertissement !== null) premium.parametres.avertissementMinutes = avertissement;
            if (notes !== null) premium.parametres.notes = notes;
        });

        const embed = new EmbedBuilder()
            .setColor(client.config.couleurs.principale)
            .setTitle(t("premium.reglages.titre", {}, L))
            .addFields(
                {
                    name: t("premium.reglages.inactivite", {}, L),
                    value: parametres.inactiviteHeures > 0
                        ? t("premium.reglages.inactiviteValeur", { heures: parametres.inactiviteHeures }, L)
                        : t("premium.reglages.desactivee", {}, L),
                    inline: true,
                },
                {
                    name: t("premium.reglages.avertissement", {}, L),
                    value: t("premium.reglages.avertissementValeur", { minutes: parametres.avertissementMinutes }, L),
                    inline: true,
                },
                {
                    name: t("premium.reglages.notes", {}, L),
                    value: parametres.notes ? t("premium.reglages.activees", {}, L) : t("premium.reglages.desactivees", {}, L),
                    inline: true,
                },
            )
            .setDescription(t("premium.reglages.aide", {}, L))
            .setFooter({ text: piedDePage(client, L) });

        return interaction.reply({ embeds: [embed], flags: MessageFlags.Ephemeral });
    },
};