// sukitickets/src/premium/commands/priorite.js

/* ===================================================
   /priorite niveau — change la priorité du ticket
   (réservé au staff, dans un salon de ticket).
   Un emoji s'ajoute au début du nom du salon :
     🟢 basse · 🟡 normale · 🔴 urgente
   Discord limite les renommages à 2 toutes les
   10 minutes par salon : le bot prévient si besoin.
   =================================================== */

const { SlashCommandBuilder, InteractionContextType, MessageFlags, EmbedBuilder } = require("discord.js");

const { t, localisations } = require("../../utils/langue");
const { lireTickets, ecrireTickets } = require("../../utils/donnees");
const { verifierCommandeTicket } = require("../../utils/staff");
const { envoyerLog } = require("../../tickets/logs");
const { PRIORITES } = require("../outils");

const ATTENTE_MAX = 4000;

// Retire un emoji de priorité déjà présent au début du nom
const PREFIXE_EXISTANT = /^(🟢|🟡|🔴)[-・]?/u;

module.exports = {
    data: new SlashCommandBuilder()
        .setName("priorite")
        .setNameLocalizations({ "en-US": "priority", "en-GB": "priority", fr: "priorite" })
        .setDescription(t("premium.commandes.priorite.description", {}, "en"))
        .setDescriptionLocalizations(localisations("premium.commandes.priorite.description"))
        .setContexts(InteractionContextType.Guild)
        .addStringOption((option) => option
            .setName("niveau")
            .setNameLocalizations({ "en-US": "level", "en-GB": "level" })
            .setDescription(t("premium.commandes.priorite.optionNiveau", {}, "en"))
            .setDescriptionLocalizations(localisations("premium.commandes.priorite.optionNiveau"))
            .setRequired(true)
            .addChoices(...Object.entries(PRIORITES).map(([niveau, emoji]) => ({
                name: `${emoji} ${t(`premium.commandes.priorite.${niveau}`, {}, "en")}`,
                name_localizations: Object.fromEntries(
                    Object.entries(localisations(`premium.commandes.priorite.${niveau}`)).map(([locale, texte]) => [locale, `${emoji} ${texte}`]),
                ),
                value: niveau,
            })))),

    async execute(interaction, client) {
        const contexte = await verifierCommandeTicket(interaction);
        if (!contexte) return;
        const { L } = contexte;

        const niveau = interaction.options.getString("niveau");
        const emoji = PRIORITES[niveau];
        const salon = interaction.channel;
        const nouveauNom = `${emoji}-${salon.name.replace(PREFIXE_EXISTANT, "")}`;

        await interaction.deferReply({ flags: MessageFlags.Ephemeral });

        // Enregistre la priorité
        const tickets = lireTickets(interaction.guildId);
        const ticket = tickets.ouverts[salon.id];
        if (ticket) {
            ticket.priorite = niveau;
            ecrireTickets(interaction.guildId, tickets);
        }

        // Renomme le salon (Discord peut faire patienter)
        const renommage = salon.setName(nouveauNom);
        const resultat = await Promise.race([
            renommage.then(() => "fait").catch(() => "erreur"),
            new Promise((resoudre) => setTimeout(() => resoudre("lent"), ATTENTE_MAX)),
        ]);

        if (resultat === "erreur") return interaction.editReply(t("gestion.erreurPermissions", {}, L));
        await interaction.editReply(resultat === "lent" ? t("gestion.renommageLent", {}, L) : t("gestion.fait", {}, L));

        const nomNiveau = t(`premium.commandes.priorite.${niveau}`, {}, L);

        await salon.send({
            embeds: [
                new EmbedBuilder()
                    .setColor(niveau === "urgente" ? client.config.couleurs.erreur : client.config.couleurs.info)
                    .setDescription(t("premium.priorite.changee", { emoji, niveau: nomNiveau, staff: `<@${interaction.user.id}>` }, L)),
            ],
            allowedMentions: { parse: [] },
        }).catch(() => {});

        await envoyerLog(interaction.guild, client, {
            titre: t("premium.priorite.logTitre", {}, L),
            couleur: client.config.couleurs.info,
            champs: [
                { name: t("logs.champTicket", {}, L), value: `#${String(ticket?.numero ?? 0).padStart(4, "0")} · <#${salon.id}>` },
                { name: t("premium.priorite.champNiveau", {}, L), value: `${emoji} ${nomNiveau}` },
                { name: t("logs.champPar", {}, L), value: `<@${interaction.user.id}>` },
            ],
        });
    },
};