// sukitickets/src/premium/outils.js

/* ===================================================
   Outils de la version premium
   - premiumDe(reglages) : réglages premium d'un
     serveur (avec les valeurs par défaut de
     config.premium.json pour ce qui n'est pas réglé)
   - modifierPremium(idServeur, modification) :
     change ces réglages et les enregistre
   - PRIORITES : les niveaux de priorité et leur emoji
   =================================================== */

const configPremium = require("../../config.premium.json");
const { lireServeur, modifierServeur } = require("../utils/donnees");

const PRIORITES = {
    basse: "🟢",
    normale: "🟡",
    urgente: "🔴",
};

/**
 * {
 *   parametres: { inactiviteHeures, avertissementMinutes, notes },
 *   formulaires: { "<id de catégorie>": ["Question 1", "Question 2"…] }
 * }
 */
function premiumDe(reglages) {
    return {
        parametres: { ...configPremium.parDefaut, ...(reglages.premium?.parametres ?? {}) },
        formulaires: { ...(reglages.premium?.formulaires ?? {}) },
    };
}

/** modification = fonction qui modifie l'objet premium reçu */
function modifierPremium(idServeur, modification) {
    const premium = premiumDe(lireServeur(idServeur));
    modification(premium);
    modifierServeur(idServeur, { premium });
    return premium;
}

module.exports = { premiumDe, modifierPremium, PRIORITES, configPremium };