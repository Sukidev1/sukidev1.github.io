// sukitickets/src/setup/categories.js

/* ===================================================
   Écran « Catégories de tickets » du panneau /setup
   - construireEcranCategories : la liste des
     catégories, le menu de sélection et les boutons
   - construireFenetreCategorie : la petite fenêtre
     (modal) pour ajouter ou modifier une catégorie
   - nouvelIdentifiant : crée un id unique à partir
     du nom ("Aide boutique" → "aide-boutique")
   =================================================== */

const {
    EmbedBuilder,
    ActionRowBuilder,
    StringSelectMenuBuilder,
    StringSelectMenuOptionBuilder,
    ButtonBuilder,
    ButtonStyle,
    ModalBuilder,
    TextInputBuilder,
    TextInputStyle,
} = require("discord.js");

const { t } = require("../utils/langue");
const { lireServeur } = require("../utils/donnees");
const { emojiComposant } = require("../utils/emoji");

const MAX_CATEGORIES = 25;

/** "Aide boutique" → "aide-boutique" (et "aide-boutique-2" s'il existe déjà) */
function nouvelIdentifiant(nom, categories) {
    const base = nom
        .normalize("NFD").replace(/[̀-ͯ]/g, "")   // enlève les accents
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/^-|-$/g, "")
        .slice(0, 30) || "categorie";

    let id = base;
    let numero = 2;
    while (categories.some((c) => c.id === id)) id = `${base}-${numero++}`;
    return id;
}

/**
 * Écran des catégories.
 * "selection" = id de la catégorie choisie dans le menu (ou null).
 */
function construireEcranCategories(serveur, client, selection = null) {
    const reglages = lireServeur(serveur.id);
    const L = reglages.langue;
    const { categories } = reglages;
    const choisie = categories.find((c) => c.id === selection) ?? null;

    /* ---------- Liste des catégories ---------- */

    const lignes = categories.map((c, i) =>
        `**${i + 1}.** ${c.emoji ?? "🎫"} **${c.nom}**\n> ${c.description || t("categories.aucuneDescription", {}, L)}`,
    );

    let description = `${t("categories.intro", {}, L)}\n\n${lignes.join("\n")}`;
    if (choisie) description += `\n\n${t("categories.selection", { categorie: `${choisie.emoji ?? ""} ${choisie.nom}`.trim() }, L)}`;

    const embed = new EmbedBuilder()
        .setColor(client.config.couleurs.principale)
        .setTitle(t("categories.titre", {}, L))
        .setDescription(description)
        .setFooter({ text: t("categories.pied", { nombre: categories.length }, L) });

    /* ---------- Menu de sélection ---------- */

    const menu = new StringSelectMenuBuilder()
        .setCustomId("setup:cat-choisir")
        .setPlaceholder(t("categories.menu", {}, L))
        .addOptions(categories.map((c) => {
            const option = new StringSelectMenuOptionBuilder()
                .setLabel(c.nom)
                .setValue(c.id)
                .setDefault(c.id === selection);
            if (c.description) option.setDescription(c.description);
            if (c.emoji) option.setEmoji(emojiComposant(c.emoji));
            return option;
        }));

    /* ---------- Boutons ---------- */

    const idChoisie = choisie ? choisie.id : "aucune";

    const boutons = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId("setup:cat-ajouter")
            .setLabel(t("categories.boutonAjouter", {}, L))
            .setEmoji("➕")
            .setStyle(ButtonStyle.Success)
            .setDisabled(categories.length >= MAX_CATEGORIES),
        new ButtonBuilder()
            .setCustomId(`setup:cat-modifier:${idChoisie}`)
            .setLabel(t("categories.boutonModifier", {}, L))
            .setEmoji("✏️")
            .setStyle(ButtonStyle.Primary)
            .setDisabled(!choisie),
        new ButtonBuilder()
            .setCustomId(`setup:cat-supprimer:${idChoisie}`)
            .setLabel(t("categories.boutonSupprimer", {}, L))
            .setEmoji("🗑️")
            .setStyle(ButtonStyle.Danger)
            .setDisabled(!choisie || categories.length <= 1),
        new ButtonBuilder()
            .setCustomId("setup:retour")
            .setLabel(t("categories.boutonRetour", {}, L))
            .setEmoji("↩️")
            .setStyle(ButtonStyle.Secondary),
    );

    return {
        embeds: [embed],
        components: [new ActionRowBuilder().addComponents(menu), boutons],
    };
}

/**
 * Fenêtre pour ajouter (categorie = null) ou modifier une catégorie.
 */
function construireFenetreCategorie(langue, categorie = null) {
    const L = langue;

    const fenetre = new ModalBuilder()
        .setCustomId(categorie ? `setup:cat-fenetre-modif:${categorie.id}` : "setup:cat-fenetre-ajout")
        .setTitle(t(categorie ? "categories.modalModif" : "categories.modalAjout", {}, L));

    const champNom = new TextInputBuilder()
        .setCustomId("nom")
        .setLabel(t("categories.champNom", {}, L))
        .setPlaceholder(t("categories.exempleNom", {}, L))
        .setStyle(TextInputStyle.Short)
        .setMaxLength(50)
        .setRequired(true);

    const champEmoji = new TextInputBuilder()
        .setCustomId("emoji")
        .setLabel(t("categories.champEmoji", {}, L))
        .setPlaceholder(t("categories.exempleEmoji", {}, L))
        .setStyle(TextInputStyle.Short)
        .setMaxLength(64)
        .setRequired(false);

    const champDescription = new TextInputBuilder()
        .setCustomId("description")
        .setLabel(t("categories.champDescription", {}, L))
        .setPlaceholder(t("categories.exempleDescription", {}, L))
        .setStyle(TextInputStyle.Short)
        .setMaxLength(100)
        .setRequired(false);

    // En modification, les champs sont déjà remplis
    if (categorie) {
        champNom.setValue(categorie.nom);
        if (categorie.emoji) champEmoji.setValue(categorie.emoji);
        if (categorie.description) champDescription.setValue(categorie.description);
    }

    return fenetre.addComponents(
        new ActionRowBuilder().addComponents(champNom),
        new ActionRowBuilder().addComponents(champEmoji),
        new ActionRowBuilder().addComponents(champDescription),
    );
}

module.exports = { construireEcranCategories, construireFenetreCategorie, nouvelIdentifiant, MAX_CATEGORIES };