// sukitickets/src/setup/panneau.js

/* ===================================================
   Panneau de configuration (/setup)
   Construit le message affiché à l'administrateur :
   un récapitulatif ✅/❌ de chaque réglage, puis les
   menus et boutons pour tout configurer.
   (L'écran des catégories est dans setup/categories.js)
   =================================================== */

const {
    EmbedBuilder,
    ActionRowBuilder,
    RoleSelectMenuBuilder,
    ChannelSelectMenuBuilder,
    ButtonBuilder,
    ButtonStyle,
    ChannelType,
} = require("discord.js");

const { t } = require("../utils/langue");
const { lireServeur } = require("../utils/donnees");
const { etatServeur } = require("../utils/verifierConfig");
const { piedDePage } = require("../utils/marque");

/** Texte affiché pour un salon selon son état */
function texteSalon(id, etat, cleMauvaisType, langue) {
    if (etat === "nonDefini") return t("setup.nonDefini", {}, langue);
    if (etat === "introuvable") return t("setup.introuvable", {}, langue);
    if (etat === "mauvaisType") return t(cleMauvaisType, { salon: `<#${id}>` }, langue);
    return `✅ <#${id}>`;
}

/**
 * Renvoie { embeds, components } prêt à être envoyé
 * avec interaction.reply() ou interaction.update().
 */
function construirePanneau(serveur, client) {
    const reglages = lireServeur(serveur.id);
    const L = reglages.langue;
    const etat = etatServeur(serveur, reglages);
    const { couleurs } = client.config;

    /* ---------- Récapitulatif ---------- */

    const texteRoles = etat.roles.length > 0
        ? etat.roles.map((id) => `✅ <@&${id}>`).join("\n")
        : t("setup.nonDefini", {}, L);

    const textePermissions = etat.permissionsManquantes.length === 0
        ? t("setup.permissionsOk", {}, L)
        : t("setup.permissionsManquantes", {
            permissions: etat.permissionsManquantes.map((p) => t(`permissions.${p}`, {}, L)).join(", "),
        }, L);

    const embed = new EmbedBuilder()
        .setColor(etat.pret ? couleurs.succes : couleurs.principale)
        .setTitle(t("setup.titre", {}, L))
        .setDescription(t("setup.intro", {}, L))
        .addFields(
            { name: t("setup.champRoles", {}, L), value: texteRoles },
            { name: t("setup.champCategorie", {}, L), value: texteSalon(reglages.categorieTickets, etat.etatCategorie, "setup.pasUneCategorie", L), inline: true },
            {
                name: t("setup.champLogs", {}, L),
                value: texteSalon(reglages.salonLogs, etat.etatLogs, "setup.pasUnSalonTexte", L) +
                    (etat.logsPublic ? `\n${t("setup.logsPublic", {}, L)}` : ""),
                inline: true,
            },
            { name: t("setup.champPermissions", {}, L), value: textePermissions },
            { name: t("setup.champLangue", {}, L), value: t("general.nomLangue", {}, L) },
            { name: "​", value: etat.pret ? t("setup.pret", {}, L) : t("setup.pasPret", {}, L) },
        )
        .setFooter({ text: piedDePage(client, L) });

    /* ---------- Menus de sélection ---------- */

    const menuRoles = new RoleSelectMenuBuilder()
        .setCustomId("setup:roles")
        .setPlaceholder(t("setup.menuRoles", {}, L))
        .setMinValues(1)
        .setMaxValues(5);
    if (etat.roles.length > 0) menuRoles.setDefaultRoles(...etat.roles);

    const menuCategorie = new ChannelSelectMenuBuilder()
        .setCustomId("setup:categorie")
        .setPlaceholder(t("setup.menuCategorie", {}, L))
        .setChannelTypes(ChannelType.GuildCategory)
        .setMaxValues(1);
    if (etat.etatCategorie === "ok") menuCategorie.setDefaultChannels(reglages.categorieTickets);

    const menuLogs = new ChannelSelectMenuBuilder()
        .setCustomId("setup:logs")
        .setPlaceholder(t("setup.menuLogs", {}, L))
        .setChannelTypes(ChannelType.GuildText)
        .setMaxValues(1);
    if (etat.etatLogs === "ok") menuLogs.setDefaultChannels(reglages.salonLogs);

    /* ---------- Boutons ---------- */

    const boutons = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId("setup:auto")
            .setLabel(t("setup.boutonAuto", {}, L))
            .setEmoji("✨")
            .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
            .setCustomId("setup:categories")
            .setLabel(t("setup.boutonCategories", {}, L))
            .setEmoji("🗂️")
            .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
            .setCustomId("setup:langue")
            .setLabel(t("setup.boutonLangue", {}, L))
            .setEmoji("🌐")
            .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
            .setCustomId("setup:actualiser")
            .setLabel(t("setup.boutonActualiser", {}, L))
            .setEmoji("🔄")
            .setStyle(ButtonStyle.Secondary),
    );

    return {
        embeds: [embed],
        components: [
            new ActionRowBuilder().addComponents(menuRoles),
            new ActionRowBuilder().addComponents(menuCategorie),
            new ActionRowBuilder().addComponents(menuLogs),
            boutons,
        ],
    };
}

module.exports = { construirePanneau };