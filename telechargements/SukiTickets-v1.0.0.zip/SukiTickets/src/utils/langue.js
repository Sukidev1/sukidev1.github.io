// sukitickets/src/utils/langue.js

/* ===================================================
   Traductions
   Charge les fichiers de src/langues (fr.json,
   en.json…) et fournit :

   - t(cle, variables, langue)
       t("commandes.ping.titre")
       t("console.enLigne", { tag: "SukiTickets#1234" })
       t("setup.titre", {}, "en")
     Les {variables} du texte sont remplacées par
     les valeurs données. Sans langue précisée,
     c'est celle de config.json qui est utilisée.

   - localisations(cle)
     Donne la traduction d'un texte pour chaque
     langue de Discord : sert aux descriptions des
     commandes slash, qui s'affichent alors dans la
     langue de chaque utilisateur.
   =================================================== */

const fs = require("node:fs");
const path = require("node:path");

const config = require("../../config.json");

const DOSSIER_LANGUES = path.join(__dirname, "..", "langues");
const LANGUE_SECOURS = "fr";

// Correspondance entre nos langues et les codes de langue de Discord
const LOCALES_DISCORD = {
    fr: ["fr"],
    en: ["en-US", "en-GB"],
};

/** Liste les langues disponibles ("en", "fr"…) */
function languesDisponibles() {
    return fs
        .readdirSync(DOSSIER_LANGUES)
        .filter((fichier) => fichier.endsWith(".json"))
        .map((fichier) => fichier.replace(".json", ""));
}

// Les fichiers de langue sont lus une seule fois puis gardés en mémoire
const cache = {};

function textesDe(code) {
    if (!(code in cache)) {
        const fichier = path.join(DOSSIER_LANGUES, `${code}.json`);
        cache[code] = fs.existsSync(fichier) ? JSON.parse(fs.readFileSync(fichier, "utf8")) : null;
    }
    return cache[code];
}

/** Va chercher "a.b.c" dans un objet */
function chercher(objet, cle) {
    return cle.split(".").reduce((valeur, morceau) => (valeur && valeur[morceau] !== undefined ? valeur[morceau] : undefined), objet);
}

/**
 * Renvoie le texte traduit.
 * Ordre de recherche : langue demandée → langue de config.json → français.
 * Si la clé n'existe nulle part, renvoie la clé elle-même (pratique pour repérer un oubli).
 */
function t(cle, variables = {}, langue = config.langue) {
    const texte =
        chercher(textesDe(langue), cle) ??
        chercher(textesDe(config.langue), cle) ??
        chercher(textesDe(LANGUE_SECOURS), cle);

    if (typeof texte !== "string") return cle;

    return texte.replace(/\{(\w+)\}/g, (morceau, nom) => (variables[nom] !== undefined ? String(variables[nom]) : morceau));
}

/** { "fr": "…", "en-US": "…", "en-GB": "…" } pour les commandes slash */
function localisations(cle) {
    const resultat = {};

    for (const code of languesDisponibles()) {
        for (const locale of LOCALES_DISCORD[code] ?? []) {
            resultat[locale] = t(cle, {}, code);
        }
    }

    return resultat;
}

module.exports = { t, localisations, languesDisponibles };