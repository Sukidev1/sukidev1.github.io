// sukitickets/src/tickets/logs.js

/* ===================================================
   Salon de logs
   envoyerLog(serveur, client, { titre, couleur,
   champs, description, fichiers }) envoie un joli
   résumé dans le salon de logs choisi avec /setup.
   Si le salon n'existe plus ou si le bot ne peut pas
   y écrire, rien ne plante : on note juste l'erreur
   dans la console.
   =================================================== */

const { EmbedBuilder } = require("discord.js");
const { t } = require("../utils/langue");
const { lireServeur } = require("../utils/donnees");

async function envoyerLog(serveur, client, { titre, couleur, champs = [], description = null, fichiers = [] }) {
    const reglages = lireServeur(serveur.id);
    const salon = serveur.channels.cache.get(reglages.salonLogs);

    if (!salon || typeof salon.send !== "function") return null;

    const L = reglages.langue;

    const embed = new EmbedBuilder()
        .setColor(couleur ?? client.config.couleurs.info)
        .setTitle(titre)
        .addFields(champs.map((champ) => ({ inline: true, ...champ })))
        .setFooter({ text: client.estPremium ? t("general.piedPremium", {}, L) : t("general.pied", {}, L) })
        .setTimestamp();

    if (description) embed.setDescription(description);

    return salon.send({ embeds: [embed], files: fichiers, allowedMentions: { parse: [] } }).catch((erreur) => {
        console.warn(t("console.erreurLog"), erreur.message);
        return null;
    });
}

module.exports = { envoyerLog };