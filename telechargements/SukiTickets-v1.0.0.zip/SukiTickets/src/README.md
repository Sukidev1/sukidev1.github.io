# 🎫 SukiTickets — Guide d'installation

Un système de tickets simple et élégant pour ton serveur Discord, entièrement configurable depuis Discord.
*English version: see `README.en.md`.*

---

## ✨ Fonctionnalités

- **Configuration sans fichier** : tout se règle avec `/setup` (rôles staff, catégorie, salon de logs, langue)
- **Création automatique** de la catégorie des tickets et du salon de logs, avec les bonnes permissions
- **Catégories de tickets personnalisables** (nom, emoji, description), jusqu'à 25
- **Menu des tickets** envoyé avec `/panel`, mis à jour tout seul quand tu modifies les catégories
- **Tickets privés** : visibles seulement par le membre, le staff et le bot
- **Prise en charge** par le staff, **fermeture** avec confirmation
- **Transcriptions HTML** de chaque ticket, envoyées dans les logs et en message privé à l'auteur
- **Logs** des ouvertures, prises en charge, fermetures et modifications
- Commandes `/add`, `/remove` et `/rename` pour gérer un ticket
- **Français et anglais** (le bot et ses commandes)
- **Aucune base de données à installer** : tout est enregistré dans le dossier `data/`

---

## 📋 Ce qu'il te faut

- **Node.js 18.17 ou plus récent**, téléchargeable sur nodejs.org (prends la version « LTS »)
- Un **compte Discord** et un serveur où tu es administrateur
- Un ordinateur ou un serveur pour faire tourner le bot (voir « Garder le bot allumé »)

---

## 🚀 Installation

### 1. Créer le bot sur Discord

1. Va sur **discord.com/developers/applications** et clique sur **New Application**. Donne-lui un nom.
2. Dans **General Information**, copie l'**Application ID** : c'est ton `CLIENT_ID`.
3. Dans l'onglet **Bot** :
   - clique sur **Reset Token** et copie le token : c'est ton `TOKEN` (ne le partage jamais) ;
   - dans **Privileged Gateway Intents**, active **Message Content Intent** (indispensable pour les transcriptions), puis **Save Changes**.

### 2. Inviter le bot sur ton serveur

Ouvre ce lien dans ton navigateur, en remplaçant `TON_CLIENT_ID` par ton Application ID :

```
https://discord.com/oauth2/authorize?client_id=TON_CLIENT_ID&scope=bot+applications.commands&permissions=268561424
```

Il donne au bot exactement les permissions dont il a besoin : voir les salons, gérer les salons, gérer les rôles, gérer les messages, envoyer des messages, intégrer des liens, joindre des fichiers et voir les anciens messages.

### 3. Préparer les fichiers

1. Décompresse l'archive où tu veux.
2. Copie le fichier `.env.example`, renomme la copie en **`.env`** et remplis-la :
   ```
   TOKEN=ton_token
   CLIENT_ID=ton_application_id
   GUILD_ID=id_de_ton_serveur
   ```
   Pour l'ID du serveur : dans Discord, active **Paramètres → Avancés → Mode développeur**, puis fais un clic droit sur ton serveur → **Copier l'identifiant du serveur**.
   *Si tu veux utiliser le bot sur plusieurs serveurs, laisse `GUILD_ID` vide : les commandes apparaîtront partout (jusqu'à 1 heure d'attente la première fois).*

### 4. Installer et lancer

Ouvre un terminal dans le dossier du bot et tape :

```
npm install
npm run deploy
npm start
```

- `npm install` installe ce dont le bot a besoin (une seule fois) ;
- `npm run deploy` enregistre les commandes auprès de Discord (à refaire après chaque mise à jour) ;
- `npm start` lance le bot.

Tu dois voir « ✅ … est en ligne » dans le terminal.

### 5. Configurer sur Discord

1. Tape **`/setup`** sur ton serveur.
2. Choisis le ou les **rôles staff**.
3. Clique sur **✨ Tout créer automatiquement** (ou choisis toi-même une catégorie et un salon de logs).
4. Si tu veux, clique sur **🗂️ Catégories de tickets** pour ajouter, modifier ou supprimer des catégories.
5. Quand le panneau affiche **« Tout est prêt ! »**, va dans le salon où les membres ouvriront leurs tickets et tape **`/panel`**.

C'est terminé ! 🎉

---

## 💬 Commandes

| Commande (FR / EN) | Qui | Rôle |
|---|---|---|
| `/setup` | Administrateurs | Panneau de configuration |
| `/panel` | Administrateurs | Envoie le menu des tickets (options : salon, titre, description) |
| `/ajouter` · `/add` | Staff | Ajoute un membre au ticket |
| `/retirer` · `/remove` | Staff | Retire un membre du ticket |
| `/renommer` · `/rename` | Staff | Renomme le salon du ticket |
| `/ping` | Tout le monde | Vérifie que le bot répond |

Les commandes s'affichent dans la langue de Discord de chaque utilisateur.
Dans `/panel`, tu peux écrire `\n` dans la description pour aller à la ligne.

---

## ⚙️ Personnaliser `config.json` (facultatif)

| Réglage | Rôle |
|---|---|
| `langue` | Langue par défaut des nouveaux serveurs et de la console : `"fr"` ou `"en"` |
| `statut.type` / `statut.texte` | Statut affiché sous le nom du bot (`Watching`, `Playing`, `Listening`…) |
| `couleurs` | Couleurs des messages, au format `#RRGGBB` |
| `tickets.maxParMembre` | Nombre de tickets ouverts en même temps par membre |
| `tickets.delaiFermeture` | Secondes avant la suppression d'un ticket fermé |
| `categoriesParDefaut` | Catégories proposées à un serveur qui n'a encore rien configuré |

Redémarre le bot après avoir modifié ce fichier. Si un réglage est incorrect, le bot te l'indique clairement au démarrage.

---

## 🌙 Garder le bot allumé

Le bot fonctionne tant que le terminal est ouvert. Pour qu'il tourne en continu :

- **Sur un ordinateur ou un serveur (VPS)**, utilise **pm2** :
  ```
  npm install -g pm2
  pm2 start src/index.js --name sukitickets
  pm2 save
  ```
  Commandes utiles : `pm2 logs sukitickets`, `pm2 restart sukitickets`, `pm2 stop sukitickets`.
  Sous Linux, `pm2 startup` permet de relancer le bot automatiquement au démarrage de la machine.
- **Chez un hébergeur de bots Discord** : envoie tous les fichiers (sauf `node_modules`), mets la commande de démarrage sur `npm start` et ajoute tes variables `TOKEN`, `CLIENT_ID` et `GUILD_ID`.

---

## 🔄 Mettre à jour

1. Arrête le bot.
2. Remplace les fichiers par ceux de la nouvelle version, **sauf** `.env`, le dossier `data/` et ton `config.json` si tu l'as personnalisé.
3. Tape `npm install`, puis `npm run deploy`, puis relance le bot.

---

## ❓ Problèmes fréquents

**Les commandes n'apparaissent pas.**
Lance `npm run deploy`, puis appuie sur **Ctrl + R** dans Discord pour le recharger. Sans `GUILD_ID`, il faut parfois attendre jusqu'à une heure.

**Erreur « Used disallowed intents » au démarrage.**
Active **Message Content Intent** dans l'onglet Bot du Developer Portal.

**Le bot dit qu'il lui manque des permissions.**
`/setup` indique exactement lesquelles. Réinvite le bot avec le lien de l'étape 2, ou donne-les à son rôle dans les paramètres du serveur.

**« Les tickets ne sont pas disponibles pour le moment ».**
Un réglage n'est plus valide (un salon ou un rôle a été supprimé). Refais `/setup` : le panneau t'indique quoi corriger.

**Les images d'une ancienne transcription ne s'affichent plus.**
C'est normal : Discord rend les liens des images temporaires. Le texte de la conversation, lui, reste toujours lisible.

---

✦ Créé par **SukiDev** — sukidev1.github.io