// sukitickets/src/commands/ping.js

/* ===================================================
   /ping — vérifie que le bot répond
   et affiche sa latence.
   =================================================== */

const { SlashCommandBuilder, EmbedBuilder, MessageFlags } = require("discord.js");
const { t, localisations } = require("../utils/langue");
const { lireServeur } = require("../utils/donnees");

module.exports = {
    data: new SlashCommandBuilder()
        .setName("ping")
        .setDescription(t("commandes.ping.description", {}, "en"))
        .setDescriptionLocalizations(localisations("commandes.ping.description")),

    async execute(interaction, client) {
        const L = interaction.guildId ? lireServeur(interaction.guildId).langue : client.config.langue;
        const latence = Math.round(client.ws.ping);

        const embed = new EmbedBuilder()
            .setColor(client.config.couleurs.principale)
            .setTitle(t("commandes.ping.titre", {}, L))
            .setDescription(t("commandes.ping.latence", { latence }, L))
            .setFooter({ text: client.estPremium ? t("general.piedPremium", {}, L) : t("general.pied", {}, L) });

        await interaction.reply({
            embeds: [embed],
            flags: MessageFlags.Ephemeral, // visible seulement par la personne qui tape la commande
        });
    },
};