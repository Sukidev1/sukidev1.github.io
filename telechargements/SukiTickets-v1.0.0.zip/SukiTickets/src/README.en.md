# 🎫 SukiTickets — Setup guide

A simple and elegant ticket system for your Discord server, fully configurable from Discord.
*Version française : voir `README.md`.*

---

## ✨ Features

- **No file to edit**: everything is set up with `/setup` (staff roles, category, log channel, language)
- **Automatic creation** of the ticket category and log channel, with the right permissions
- **Custom ticket categories** (name, emoji, description), up to 25
- **Ticket menu** posted with `/panel`, updated automatically when you edit categories
- **Private tickets**: only visible to the member, staff and the bot
- **Claiming** by staff, **closing** with confirmation
- **HTML transcripts** of every ticket, sent to the logs and to the author by DM
- **Logs** for openings, claims, closings and changes
- `/add`, `/remove` and `/rename` commands to manage a ticket
- **English and French** (the bot and its commands)
- **No database to install**: everything is saved in the `data/` folder

---

## 📋 Requirements

- **Node.js 18.17 or newer**, from nodejs.org (pick the "LTS" version)
- A **Discord account** and a server where you are an administrator
- A computer or server to run the bot (see "Keeping the bot online")

---

## 🚀 Installation

### 1. Create the bot on Discord

1. Go to **discord.com/developers/applications** and click **New Application**. Give it a name.
2. In **General Information**, copy the **Application ID**: this is your `CLIENT_ID`.
3. In the **Bot** tab:
   - click **Reset Token** and copy the token: this is your `TOKEN` (never share it);
   - under **Privileged Gateway Intents**, enable **Message Content Intent** (required for transcripts), then **Save Changes**.

### 2. Invite the bot to your server

Open this link in your browser, replacing `YOUR_CLIENT_ID` with your Application ID:

```
https://discord.com/oauth2/authorize?client_id=YOUR_CLIENT_ID&scope=bot+applications.commands&permissions=268561424
```

It gives the bot exactly the permissions it needs: view channels, manage channels, manage roles, manage messages, send messages, embed links, attach files and read message history.

### 3. Prepare the files

1. Unzip the archive anywhere you like.
2. Copy `.env.example`, rename the copy to **`.env`** and fill it in:
   ```
   TOKEN=your_token
   CLIENT_ID=your_application_id
   GUILD_ID=your_server_id
   ```
   For the server ID: in Discord, enable **Settings → Advanced → Developer Mode**, then right-click your server → **Copy Server ID**.
   *To use the bot on several servers, leave `GUILD_ID` empty: commands will appear everywhere (up to 1 hour the first time).*

### 4. Install and start

Open a terminal in the bot folder and type:

```
npm install
npm run deploy
npm start
```

- `npm install` installs what the bot needs (once);
- `npm run deploy` registers the commands with Discord (run it again after each update);
- `npm start` starts the bot.

The bot's console messages follow the `langue` setting in `config.json` (French by default). Set it to `"en"` for English.

### 5. Set it up on Discord

1. Type **`/setup`** on your server.
2. Pick the **staff role(s)**.
3. Click **✨ Create everything for me** (or pick a category and log channel yourself).
4. Optionally, click **🗂️ Ticket categories** to add, edit or delete categories.
5. Once the panel says **"All set!"**, go to the channel where members will open tickets and type **`/panel`**.

You're done! 🎉

---

## 💬 Commands

| Command (EN / FR) | Who | What it does |
|---|---|---|
| `/setup` | Administrators | Setup panel |
| `/panel` | Administrators | Posts the ticket menu (options: channel, title, description) |
| `/add` · `/ajouter` | Staff | Adds a member to the ticket |
| `/remove` · `/retirer` | Staff | Removes a member from the ticket |
| `/rename` · `/renommer` | Staff | Renames the ticket channel |
| `/ping` | Everyone | Checks that the bot is responding |

Commands are shown in each user's Discord language.
In `/panel`, you can type `\n` in the description to start a new line.

---

## ⚙️ Customising `config.json` (optional)

| Setting | What it does |
|---|---|
| `langue` | Default language for new servers and the console: `"fr"` or `"en"` |
| `statut.type` / `statut.texte` | Status shown under the bot's name (`Watching`, `Playing`, `Listening`…) |
| `couleurs` | Message colors, as `#RRGGBB` |
| `tickets.maxParMembre` | How many open tickets a member can have at once |
| `tickets.delaiFermeture` | Seconds before a closed ticket is deleted |
| `categoriesParDefaut` | Categories offered to a server that hasn't set anything up yet |

Restart the bot after editing this file. If a setting is wrong, the bot tells you clearly on startup.

---

## 🌙 Keeping the bot online

The bot runs as long as the terminal is open. To keep it running all the time:

- **On a computer or a server (VPS)**, use **pm2**:
  ```
  npm install -g pm2
  pm2 start src/index.js --name sukitickets
  pm2 save
  ```
  Useful commands: `pm2 logs sukitickets`, `pm2 restart sukitickets`, `pm2 stop sukitickets`.
  On Linux, `pm2 startup` restarts the bot automatically when the machine boots.
- **With a Discord bot host**: upload all files (except `node_modules`), set the start command to `npm start` and add your `TOKEN`, `CLIENT_ID` and `GUILD_ID` variables.

---

## 🔄 Updating

1. Stop the bot.
2. Replace the files with the new version, **except** `.env`, the `data/` folder and your `config.json` if you customised it.
3. Run `npm install`, then `npm run deploy`, then start the bot again.

---

## ❓ Troubleshooting

**Commands don't show up.**
Run `npm run deploy`, then press **Ctrl + R** in Discord to reload it. Without `GUILD_ID`, it can take up to an hour.

**"Used disallowed intents" error on startup.**
Enable **Message Content Intent** in the Bot tab of the Developer Portal.

**The bot says it's missing permissions.**
`/setup` tells you exactly which ones. Re-invite the bot with the link from step 2, or give them to its role in the server settings.

**"Tickets aren't available right now".**
A setting is no longer valid (a channel or role was deleted). Run `/setup` again: the panel shows what to fix.

**Images in an old transcript no longer show.**
That's expected: Discord makes image links temporary. The conversation text always stays readable.

---

✦ Made by **SukiDev** — sukidev1.github.io